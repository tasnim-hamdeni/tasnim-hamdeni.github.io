import {test} from 'node:test';
import assert from 'node:assert/strict';
import {File} from 'node:buffer';
import {applyChange,validateCatalog,validateFile,readPublicCatalog} from '../site/core.js';
import {GitHubLibrary} from '../site/github.js';

const empty=()=>({version:1,subjects:[],lessons:[]});
const subject={id:'subject-1',name:'Science'};
const lesson={id:'lesson-1',subjectId:subject.id,title:'A lesson',type:'pdf',originalName:'notes.pdf',size:12,uploadedAt:'2026-10-25T12:00:00Z',path:'documents/subject-1/lesson-1.pdf'};
const seeded=()=>({version:1,subjects:[subject],lessons:[lesson]});
const response=(data,status=200)=>({ok:status>=200&&status<300,status,json:async()=>data});
const encode=value=>Buffer.from(JSON.stringify(value)).toString('base64');

test('empty catalog is valid; adding a subject is persistent catalog data',()=>{
  const source=empty(),next=applyChange(source,{kind:'add-subject',subject});
  assert.equal(source.subjects.length,0);assert.deepEqual(next.subjects,[subject]);
  assert.throws(()=>applyChange(next,{kind:'add-subject',subject:{id:'other',name:'science'}}),/already exists/);
});
test('catalog rejects executable paths, duplicate identifiers and missing subjects',()=>{
  for(const patch of [{path:'javascript:alert(1)'},{path:'documents/../notes.pdf'},{subjectId:'missing'},{size:-1},{uploadedAt:'not-a-date'}])assert.throws(()=>validateCatalog({...seeded(),lessons:[{...lesson,...patch}]}),/invalid/);
  assert.throws(()=>validateCatalog({...seeded(),lessons:[lesson,lesson]}),/invalid/);
  const title='<img src=x onerror=alert(1)>';
  assert.equal(validateCatalog({...seeded(),lessons:[{...lesson,title}]}).lessons[0].title,title,'titles are text; rendering uses textContent');
});
test('removal protects occupied subjects and handles stale deletions',()=>{
  assert.throws(()=>applyChange(seeded(),{kind:'remove-subject',id:subject.id}),/lessons before/);
  const next=applyChange(seeded(),{kind:'remove-lesson',id:lesson.id,path:lesson.path});
  assert.equal(next.lessons.length,0);
  assert.equal(applyChange(next,{kind:'remove-subject',id:subject.id}).subjects.length,0);
  assert.throws(()=>applyChange(next,{kind:'remove-lesson',id:lesson.id,path:lesson.path}),/changed or was removed/);
  assert.throws(()=>applyChange(empty(),{kind:'upload',lesson}),/no longer exists/);
});
test('validates PDF extension, MIME, signature, empty input and size limit',async()=>{
  assert.equal(await validateFile(new File(['%PDF-1.7\n'], 'notes.PDF',{type:'application/pdf'})),'pdf');
  assert.equal(await validateFile(new File(['%PDF-1.7\n'], 'notes.pdf')),'pdf');
  await assert.rejects(validateFile(new File(['<script>'], 'notes.pdf',{type:'application/pdf'})),/signature/);
  await assert.rejects(validateFile(new File(['%PDF-1.7'], 'notes.pdf',{type:'text/html'})),/Only PDF/);
  await assert.rejects(validateFile(new File(['abc'], 'notes.exe')),/Only PDF/);
  await assert.rejects(validateFile(new File([], 'notes.pdf')),/non-empty/);
  await assert.rejects(validateFile({size:50*1024*1024+1,name:'large.pdf'}),/exceeds/);
});
function zipDirectory(names) {
  const local=Buffer.from([0x50,0x4b,3,4,0,0,0,0]);
  const entries=names.map(name=>{const bytes=Buffer.from(name),header=Buffer.alloc(46);header.writeUInt32LE(0x02014b50);header.writeUInt16LE(bytes.length,28);return Buffer.concat([header,bytes]);});
  const directory=Buffer.concat(entries),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(local.length,16);
  return Buffer.concat([local,directory,end]);
}
test('PPTX signature and ZIP directory distinguish presentations from renamed ZIPs',async()=>{
  const pptx=new File([zipDirectory(['[Content_Types].xml','ppt/presentation.xml'])],'slides.pptx',{type:'application/vnd.openxmlformats-officedocument.presentationml.presentation'});
  assert.equal(await validateFile(pptx),'pptx');
  await assert.rejects(validateFile(new File([zipDirectory(['word/document.xml'])],'bad.pptx')),/PowerPoint/);
  await assert.rejects(validateFile(new File(['PK\u0003\u0004garbage'],'bad.pptx')),/damaged/);
});

function mockGitHub({conflict=false,failBlob=false,failPatch=false,privateRepo=false,concurrentDelete=false}={}) {
  let current=seeded(),head='head-1',trees=[],pending,conflicted=false,blobCalls=0;
  const requests=[];
  const fetch=async(url,options)=>{
    const route=url.split('/tasnim-lesson-data')[1],body=options.body?JSON.parse(options.body):undefined;
    requests.push({route,method:options.method,body,headers:options.headers});
    if(route==='')return response({private:privateRepo,permissions:{push:true}});
    if(route==='/git/ref/heads/main')return response({object:{sha:head}});
    if(route.startsWith('/git/commits/')&&options.method==='GET')return response({tree:{sha:'base-tree'}});
    if(route.startsWith('/contents/catalog.json'))return response({encoding:'base64',content:encode(current)});
    if(route==='/git/blobs'){blobCalls++;return failBlob?response({},500):response({sha:'document-blob'});}
    if(route==='/git/trees'){trees.push(body);pending=JSON.parse(body.tree[0].content);return response({sha:'new-tree'});}
    if(route==='/git/commits')return response({sha:`new-commit-${trees.length}`});
    if(route==='/git/refs/heads/main'){
      assert.equal(body.force,false);
      if(failPatch)throw new Error('network interrupted');
      if(conflict&&!conflicted){conflicted=true;head='other-head';current=concurrentDelete?empty():{...current,subjects:[...current.subjects,{id:'concurrent',name:'Concurrent subject'}]};return response({},422);}
      current=pending;head=body.sha;return response({object:{sha:head}});
    }
    throw new Error('Unexpected request '+route);
  };
  return {fetch,requests,trees,get catalog(){return current;},get blobCalls(){return blobCalls;}};
}
test('connect reads a public repository and rejects private storage',async()=>{
  const mock=mockGitHub(),client=new GitHubLibrary('test-only-sentinel',mock.fetch);
  assert.equal((await client.connect()).lessons.length,1);
  await assert.rejects(new GitHubLibrary('test-only-sentinel',mockGitHub({privateRepo:true}).fetch).connect(),/must be public/);
  client.disconnect();await assert.rejects(client.snapshot(),/Connect with/);
});
test('the browser fetch function is called without a foreign receiver',async()=>{
  const mock=mockGitHub();
  const request=function(...args){assert.equal(this,undefined);return mock.fetch(...args);};
  const client=new GitHubLibrary('test-only-sentinel',request);
  await client.connect();
});
test('subject changes commit JSON using a non-forced branch update',async()=>{
  const mock=mockGitHub(),client=new GitHubLibrary('test-only-sentinel',mock.fetch);
  const result=await client.publish({kind:'add-subject',subject:{id:'new',name:'New subject'}});
  assert.equal(result.subjects.length,2);assert.equal(mock.catalog.subjects.length,2);
  assert.equal(mock.requests.at(-1).method,'PATCH');
  assert.equal(mock.requests.at(-1).body.force,false);
  for(const request of mock.requests){assert.equal(request.headers.Authorization,'Bearer test-only-sentinel');assert.ok(!JSON.stringify(request.body??'').includes('test-only-sentinel'));}
});
test('concurrent subject edits are rebased without losing the other edit',async()=>{
  const mock=mockGitHub({conflict:true}),client=new GitHubLibrary('test-only-sentinel',mock.fetch);
  const result=await client.publish({kind:'add-subject',subject:{id:'new',name:'New subject'}});
  assert.equal(mock.trees.length,2);assert.deepEqual(result.subjects.map(s=>s.id),['subject-1','concurrent','new']);
});
test('a concurrent deletion prevents uploading to a removed subject',async()=>{
  const mock=mockGitHub({conflict:true,concurrentDelete:true}),client=new GitHubLibrary('test-only-sentinel',mock.fetch);
  await assert.rejects(client.publish({kind:'upload',lesson:{...lesson,id:'new',path:'documents/subject-1/new.pdf'}}),/no longer exists/);
  assert.equal(mock.catalog.lessons.length,0);
});
test('lesson removal deletes the document and catalog entry in one tree',async()=>{
  const mock=mockGitHub(),client=new GitHubLibrary('test-only-sentinel',mock.fetch);
  await client.publish({kind:'remove-lesson',id:lesson.id,path:lesson.path});
  assert.equal(mock.catalog.lessons.length,0);assert.deepEqual(mock.trees[0].tree[1],{path:lesson.path,mode:'100644',type:'blob',sha:null});
});
// Browser FileReader adapter for the integration boundary; it never touches a credential.
globalThis.FileReader=class {
  readAsDataURL(file){file.arrayBuffer().then(bytes=>{this.result='data:application/pdf;base64,'+Buffer.from(bytes).toString('base64');this.onload();}).catch(()=>this.onerror());}
};
const newLesson={...lesson,id:'new-lesson',path:'documents/subject-1/new-lesson.pdf'};
test('upload publishes one document and catalog together; retries reuse the same blob',async()=>{
  const mock=mockGitHub({conflict:true}),client=new GitHubLibrary('test-only-sentinel',mock.fetch);
  await client.publish({kind:'upload',lesson:newLesson},new File(['%PDF-1.7'],'notes.pdf'));
  assert.equal(mock.blobCalls,1);assert.equal(mock.catalog.lessons.length,2);
  assert.equal(mock.trees.at(-1).tree[1].sha,'document-blob');
});
test('failed blob upload cannot update the catalog or report success',async()=>{
  const mock=mockGitHub({failBlob:true}),client=new GitHubLibrary('test-only-sentinel',mock.fetch);
  await assert.rejects(client.publish({kind:'upload',lesson:newLesson},new File(['%PDF-1.7'],'notes.pdf')),/HTTP 500/);
  assert.equal(mock.trees.length,0);assert.equal(mock.catalog.lessons.length,1);
});
test('an ambiguous publication response never reports success',async()=>{
  const mock=mockGitHub({failPatch:true}),client=new GitHubLibrary('test-only-sentinel',mock.fetch);
  await assert.rejects(client.publish({kind:'add-subject',subject:{id:'new',name:'New'}}),/could not be confirmed/);
});
test('public access uses no credentials and reports missing setup accurately',async()=>{
  const original=globalThis.fetch;
  try{
    globalThis.fetch=async(url,options)=>{assert.equal(options.credentials,'omit');assert.equal(options.headers,undefined);assert.equal(options.cache,'no-store');return response(empty());};
    assert.deepEqual(await readPublicCatalog(),empty());
    globalThis.fetch=async()=>response({},404);
    await assert.rejects(readPublicCatalog(),/has not been connected/);
  }finally{globalThis.fetch=original;}
});
