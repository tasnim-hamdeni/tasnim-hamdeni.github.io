// Isolated browser QA only. No requests go to GitHub, and all test changes vanish on exit.
// Production site files never include this server or its endpoint substitutions.
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.resolve(fileURLToPath(new URL('../site/',import.meta.url)));
const origin='http://127.0.0.1:4174';
const hash=value=>createHash('sha1').update(value).digest('hex');
const blobs=new Map(),trees=new Map(),commits=new Map();
const initialCatalog=await readFile(new URL('../lesson-data/catalog.json',import.meta.url),'utf8');
const initialTree={'catalog.json':Buffer.from(initialCatalog)};
let counter=0,head=hash('initial');trees.set('initial-tree',initialTree);commits.set(head,{tree:'initial-tree',parent:null});
const currentFiles=()=>trees.get(commits.get(head).tree);
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'};
function json(res,data,status=200){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
http.createServer(async(req,res)=>{
  try {
    const url=new URL(req.url,origin),route=url.pathname;
    if(route==='/__responsive'){
      res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end('<!doctype html><html lang="en"><head><title>Local responsive QA</title><style>body{margin:20px;background:#ddd;font:14px system-ui}main{display:flex;gap:24px}iframe{width:390px;height:844px;border:1px solid #777;flex-shrink:0}h1{font-size:20px}</style></head><body><h1>Local QA — student and admin, each in a 390px viewport</h1><main><iframe title="Student phone layout" src="/"></iframe><iframe title="Admin phone layout" src="/tasnim/"></iframe></main></body></html>');return;
    }
    if(route.startsWith('/__raw__/')){
      const relative=route.split('/main/')[1],content=currentFiles()[relative];
      if(!content){json(res,{},404);return;}
      res.writeHead(200,{'Content-Type':relative.endsWith('.json')?'application/json':'application/octet-stream','Cache-Control':'no-store'});res.end(content);return;
    }
    if(route.startsWith('/__api__/repos/tasnim-hamdeni/tasnim-lesson-data')){
      const api=route.slice('/__api__/repos/tasnim-hamdeni/tasnim-lesson-data'.length);
      let body; if(req.method!=='GET'){const chunks=[];for await(const chunk of req)chunks.push(chunk);body=JSON.parse(Buffer.concat(chunks).toString()||'{}');}
      if(api===''){json(res,{private:false,permissions:{push:true}});return;}
      if(api==='/git/ref/heads/main'){json(res,{object:{sha:head}});return;}
      if(api.startsWith('/git/commits/')&&req.method==='GET'){const commit=commits.get(api.split('/').pop());json(res,{tree:{sha:commit.tree}});return;}
      if(api==='/contents/catalog.json'){
        const files=trees.get(commits.get(url.searchParams.get('ref')).tree);
        json(res,{encoding:'base64',content:files['catalog.json'].toString('base64')});return;
      }
      if(api==='/git/blobs'){
        const bytes=Buffer.from(body.content,'base64'),sha=hash(bytes);blobs.set(sha,bytes);json(res,{sha},201);return;
      }
      if(api==='/git/trees'){
        const files={...trees.get(body.base_tree)};
        for(const entry of body.tree){if(entry.sha===null)delete files[entry.path];else files[entry.path]=entry.content!==undefined?Buffer.from(entry.content):blobs.get(entry.sha);}
        const sha=hash('tree'+(++counter));trees.set(sha,files);json(res,{sha},201);return;
      }
      if(api==='/git/commits'){
        const sha=hash('commit'+(++counter));commits.set(sha,{tree:body.tree,parent:body.parents[0]});json(res,{sha},201);return;
      }
      if(api==='/git/refs/heads/main'){
        if(body.force!==false||commits.get(body.sha).parent!==head){json(res,{},422);return;}
        head=body.sha;json(res,{object:{sha:head}});return;
      }
      json(res,{},404);return;
    }
    const pathname=decodeURIComponent(route),file=path.resolve(root,'.'+(pathname.endsWith('/')?pathname+'index.html':pathname));
    if(!file.startsWith(root+path.sep)){json(res,{},403);return;}
    let bytes=await readFile(file);
    if(file.endsWith('core.js'))bytes=Buffer.from(bytes.toString().replaceAll('https://api.github.com/repos/',origin+'/__api__/repos/').replaceAll('https://raw.githubusercontent.com/',origin+'/__raw__/'));
    if(file.endsWith('.html'))bytes=Buffer.from(bytes.toString().replace('<body>','<body><aside class="public-notice"><strong>LOCAL QA ONLY</strong> — isolated in-memory test repository. No GitHub changes are made here.</aside>'));
    res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(bytes);
  }catch{json(res,{error:'Local QA request failed'},500);}
}).listen(4174,'127.0.0.1',()=>console.log('Isolated QA: http://127.0.0.1:4174 — all changes are temporary; GitHub is never contacted.'));
