"""Generate disposable browser QA files under artifacts/; never include them in the ZIP."""
from pathlib import Path
from zipfile import ZipFile

folder = Path(__file__).resolve().parents[1] / "artifacts"
folder.mkdir(exist_ok=True)
objects = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Count 1 /Kids [3 0 R] >>", b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 300] >>"]
pdf = bytearray(b"%PDF-1.4\n")
offsets = [0]
for number, obj in enumerate(objects, 1):
    offsets.append(len(pdf))
    pdf.extend(f"{number} 0 obj\n".encode() + obj + b"\nendobj\n")
xref = len(pdf)
pdf.extend(b"xref\n0 4\n0000000000 65535 f \n")
for offset in offsets[1:]:
    pdf.extend(f"{offset:010d} 00000 n \n".encode())
pdf.extend(f"trailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
(folder / "browser-test.pdf").write_bytes(pdf)
with ZipFile(folder / "browser-test.pptx", "w") as archive:
    archive.writestr("[Content_Types].xml", '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')
    archive.writestr("ppt/presentation.xml", '<?xml version="1.0"?><p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"/>')
(folder / "invalid.pdf").write_text("This is not a PDF.")
print("Disposable fixtures generated in artifacts/.")
