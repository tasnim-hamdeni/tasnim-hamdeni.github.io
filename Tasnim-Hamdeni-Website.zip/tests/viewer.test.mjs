import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';
const source=name=>readFile(new URL('../site/'+name,import.meta.url),'utf8');
const until=async check=>{for(let i=0;i<100;i++){if(check())return;await new Promise(r=>setTimeout(r,5));}assert.ok(check());};
async function viewer({id='notes',bytes='%PDF-1.7\n',title='<img src=x onerror=alert(1)>'}={}){
 const dom=new JSDOM(await source('viewer.html'),{url:'https://tasnim-hamdeni.github.io/viewer.html?lesson='+id,runScripts:'outside-only'}),w=dom.window;
 let renders=0,loads=0,requests=0;
 const catalog={subjects:[{id:'ai',name:'AI'}],chapters:[{id:'c',subjectId:'ai',name:'Chapter'}],lessons:[{id:'notes',subjectId:'ai',chapterId:'c',title,type:'pdf',size:9,originalName:'notes.pdf',example:true}]};
 Object.assign(w,{TextDecoder,Blob,AbortSignal});w.URL.createObjectURL=()=> 'blob:https://tasnim-hamdeni.github.io/test';w.URL.revokeObjectURL=()=>{};
 w.HTMLCanvasElement.prototype.getContext=()=>({});
 w.GlobalWorkerOptions={};w.readPublicCatalog=async()=>catalog;w.lessonURL=()=> 'https://raw.githubusercontent.com/tasnim-hamdeni/tasnim-lesson-data/main/documents/ai/c/notes.pdf';w.formatSize=()=> '1 KB';
 w.fetch=async()=>{requests++;return {ok:true,arrayBuffer:async()=>new TextEncoder().encode(bytes).buffer};};
 w.getDocument=()=>{loads++;return {promise:Promise.resolve({numPages:2,getPage:async n=>({getViewport:({scale})=>({width:600*scale,height:800*scale}),render:()=>{renders++;return {promise:Promise.resolve()};},getTextContent:async()=>({items:[{str:'Page '+n+' text'}]}),cleanup(){}})})};};
 w.eval((await source('viewer.js')).replace(/^import .*;\r?\n/gm,'').replaceAll('import.meta.url',JSON.stringify('https://tasnim-hamdeni.github.io/viewer.js')));
 return {dom,w,$:id=>w.document.getElementById(id),get renders(){return renders;},get loads(){return loads;},get requests(){return requests;}};
}
test('PDF reader renders valid bytes, navigates pages, zooms, and treats titles as text',async()=>{
 const p=await viewer();try{
  await until(()=>p.$('page-count').textContent==='Page 1 of 2'&&!p.$('pdf-zoom').disabled);
  assert.equal(p.loads,1);assert.equal(p.$('document-title').querySelector('img'),null);assert.match(p.$('document-title').textContent,/<img/);
  assert.equal(p.$('previous-page').disabled,true);assert.equal(p.$('next-page').disabled,false);assert.equal(p.$('blank-notice').hidden,false);
  p.$('next-page').click();await until(()=>p.$('page-text').textContent==='Page 2 text');assert.equal(p.$('next-page').disabled,true);
  p.$('previous-page').click();await until(()=>p.$('page-text').textContent==='Page 1 text');
  p.$('pdf-zoom').value='1.5';p.$('pdf-zoom').dispatchEvent(new p.w.Event('change'));await until(()=>p.renders===4);
  assert.match(p.$('download-pdf').href,/^blob:/);assert.equal(p.$('download-pdf').download,'notes.pdf');assert.ok(!p.$('back-link').href.includes('github.com'));
 }finally{p.dom.window.close();}
});
test('PDF reader rejects missing catalog IDs and invalid or incomplete documents',async()=>{
 for(const options of [{id:'unlisted'},{bytes:'not a pdf'},{bytes:'%PDF-'}]){
  const p=await viewer(options);try{await until(()=>p.$('viewer-status').className.includes('error'));assert.equal(p.loads,0);assert.equal(p.$('pdf-reader').hidden,true);if(options.id)assert.equal(p.requests,0);}finally{p.dom.window.close();}
 }
});
