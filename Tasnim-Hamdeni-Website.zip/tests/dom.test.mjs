// DOM unit tests only: two isolated documents share an in-memory mock Git API.
// No network, real credentials, public sample lessons, or browser automation.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {File} from 'node:buffer';
import {JSDOM} from 'jsdom';
import {config} from '../site/config.js';

const source=name=>readFile(new URL('../site/'+name,import.meta.url),'utf8');
const code=name=>source(name).then(s=>s.replace(/^import .*;\r?\n/gm,'').replace(/^export /gm,''));
function sharedRepository(){
  let catalog={version:2,subjects:[],chapters:[],lessons:[]},head='head-0',counter=0,publications=0,failAt=Infinity;
  const trees=new Map(),commits=new Map(),blobs=new Map(),documents=new Map();
  const reply=(data,status=200)=>({ok:status>=200&&status<300,status,json:async()=>structuredClone(data)});
  const fetch=async(url,options={})=>{
    if(url.endsWith('/api/session'))return reply(options.method==='DELETE'?{}:{session:'a'.repeat(64),setupRequired:false});
    if(url.startsWith(config.adminService+'/api/github'))url='https://api.github.com/repos/tasnim-hamdeni/tasnim-lesson-data'+url.slice((config.adminService+'/api/github').length);
    if(url.startsWith('https://raw.githubusercontent.com/')){
      if(url.includes('/catalog.json'))return reply(catalog);
      const bytes=documents.get(url.split('/main/')[1]);
      return {ok:!!bytes,status:bytes?200:404,blob:async()=>new Blob([bytes])};
    }
    assert.ok(url.startsWith('https://api.github.com/repos/tasnim-hamdeni/tasnim-lesson-data'));
    const route=url.split('/tasnim-lesson-data')[1],body=options.body?JSON.parse(options.body):null;
    if(route==='')return reply({private:false,permissions:{push:true}});
    if(route==='/git/ref/heads/main')return reply({object:{sha:head}});
    if(route.startsWith('/git/commits/')&&options.method==='GET')return reply({tree:{sha:'base'}});
    if(route.startsWith('/contents/catalog.json'))return reply({encoding:'base64',content:Buffer.from(JSON.stringify(catalog)).toString('base64')});
    if(route==='/git/blobs'){const sha='blob-'+(++counter);blobs.set(sha,Buffer.from(body.content,'base64'));return reply({sha});}
    if(route==='/git/trees'){const sha='tree-'+(++counter);trees.set(sha,body.tree);return reply({sha});}
    if(route==='/git/commits'){const sha='commit-'+(++counter);commits.set(sha,body);return reply({sha});}
    if(route==='/git/refs/heads/main'){
      if(++publications===failAt)return reply({message:'Simulated publishing interruption'},403);
      assert.equal(body.force,false);const commit=commits.get(body.sha);assert.equal(commit.parents[0],head);
      for(const entry of trees.get(commit.tree)){
        if(entry.path==='catalog.json')catalog=JSON.parse(entry.content);
        else if(entry.sha===null)documents.delete(entry.path);else documents.set(entry.path,blobs.get(entry.sha));
      }
      head=body.sha;return reply({object:{sha:head}});
    }
    throw new Error('Unexpected mock route '+route);
  };
  return {fetch,rejectAfterSuccessfulPublications(count){failAt=publications+count+1;},get catalog(){return catalog;},get documents(){return documents;}};
}
async function page(kind,repository,suffix=''){
  const dom=new JSDOM(await source(kind==='admin'?'tasnim/index.html':'index.html'),{url:'https://tasnim-hamdeni.github.io/'+(kind==='admin'?'tasnim/':suffix),runScripts:'outside-only'});
  const w=dom.window;
  Object.assign(w,{TextEncoder,TextDecoder,structuredClone,AbortSignal,fetch:repository.fetch,Blob});
  w.crypto.randomUUID=randomUUID;
  w.FileReader=class{readAsDataURL(file){file.arrayBuffer().then(bytes=>{this.result='data:application/pdf;base64,'+Buffer.from(bytes).toString('base64');this.onload();}).catch(()=>this.onerror());}};
  w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};
  w.HTMLDialogElement.prototype.close=function(value){this.returnValue=value;this.open=false;this.dispatchEvent(new w.Event('close'));};
  w.eval(`const config=${JSON.stringify(config)};\n${await code('core.js')}\n${kind==='admin'?(await code('github.js'))+'\n'+(await code('code-access.js')):''}\n${await code(kind+'.js')}`);
  return {dom,w,$:id=>w.document.getElementById(id)};
}
async function until(check){for(let i=0;i<100;i++){if(check())return;await new Promise(r=>setTimeout(r,5));}assert.ok(check(),'Expected asynchronous state was not reached');}
function submit(p,id){p.$(id).dispatchEvent(new p.w.Event('submit',{bubbles:true,cancelable:true}));}
async function connect(p){p.$('access-code').value='482615';submit(p,'connect-form');await until(()=>!p.$('workspace').hidden&&!p.$('admin-refresh').disabled);assert.equal(p.$('access-code').value,'');}
async function addSubject(p,name){p.$('subject-name').value=name;submit(p,'subject-form');await until(()=>p.$('admin-status').textContent==='Subject added.');}
async function addChapter(p,name){p.$('chapter-name').value=name;submit(p,'chapter-form');await until(()=>p.$('admin-status').textContent==='Chapter added.');}

test('teacher creates subject → chapter → document; an independent student DOM loads it',async()=>{
  const repository=sharedRepository(),teacher=await page('admin',repository);
  try{
    assert.equal(teacher.$('workspace').hidden,true);
    assert.equal(teacher.$('subject-form').querySelector('fieldset').disabled,true);
    teacher.$('access-code').value='invalid';submit(teacher,'connect-form');assert.match(teacher.$('admin-status').textContent,/access code/);assert.equal(teacher.$('access-code').value,'');
    await connect(teacher);await addSubject(teacher,'Science');await addChapter(teacher,'First chapter');
    const file=new File(['%PDF-1.7\n'],'notes.pdf',{type:'application/pdf'});
    Object.defineProperty(teacher.$('lesson-file'),'files',{value:[file],configurable:true});
    teacher.$('lesson-title').value='<script>literal title</script>';submit(teacher,'upload-form');
    await until(()=>teacher.$('admin-status').textContent.startsWith('Published.'));
    assert.equal(repository.catalog.chapters.length,1);assert.equal(repository.catalog.lessons.length,1);assert.equal(repository.documents.size,1);
    assert.match(repository.catalog.lessons[0].path,/^documents\/[^/]+\/[^/]+\/[^/]+\.pdf$/);
    const student=await page('student',repository);
    try{
      await until(()=>student.$('subject-nav').children.length===1);
      assert.match(student.$('lessons').textContent,/First chapter/);assert.match(student.$('lessons').textContent,/<script>literal title<\/script>/);assert.equal(student.$('lessons').querySelector('script'),null);
      assert.equal(student.$('lessons').querySelectorAll('.lesson-actions a').length,1);
      const view=student.$('lessons').querySelector('.lesson-actions a');assert.match(view.getAttribute('href'),/^viewer\.html\?lesson=/);assert.ok(!view.href.includes('github.com'));
      student.$('search').value='missing';student.$('search').dispatchEvent(new student.w.Event('input'));assert.match(student.$('lessons').textContent,/No matches/);
      student.$('search').value='First chapter';student.$('search').dispatchEvent(new student.w.Event('input'));assert.equal(student.$('lessons').querySelectorAll('.lesson-row').length,1);
      student.$('subject-nav').querySelector('a').click();assert.equal(student.$('course-title').textContent,'Science');
    }finally{student.dom.window.close();}
    teacher.$('disconnect').click();assert.equal(teacher.$('workspace').hidden,true);assert.equal(teacher.$('access-code').value,'');
  }finally{teacher.dom.window.close();}
});
test('cancel preserves a chapter and its files; one confirmed deletion removes both',async()=>{
 const repository=sharedRepository(),p=await page('admin',repository);
 try{
  await connect(p);await addSubject(p,'Science');await addChapter(p,'Chapter');
  const file=new File(['%PDF-1.7\n'],'notes.pdf',{type:'application/pdf'});Object.defineProperty(p.$('lesson-file'),'files',{value:[file],configurable:true});p.$('lesson-title').value='Notes';submit(p,'upload-form');await until(()=>p.$('admin-status').textContent==='Published.');
  p.$('admin-chapters').querySelector('.remove').click();assert.equal(p.$('confirm-dialog').open,true);assert.match(p.$('confirm-message').textContent,/1 document/);
  p.$('confirm-dialog').close('cancel');await new Promise(r=>setTimeout(r,0));assert.equal(repository.catalog.lessons.length,1);assert.equal(repository.catalog.chapters.length,1);
  p.$('admin-chapters').querySelector('.remove').click();p.$('confirm-dialog').close('remove');await until(()=>p.$('admin-status').textContent==='Chapter deleted.');
  assert.equal(repository.catalog.lessons.length,0);assert.equal(repository.documents.size,0);assert.equal(repository.catalog.chapters.length,0);assert.equal(repository.catalog.subjects.length,1);
  p.$('admin-subjects').querySelector('.remove').click();p.$('confirm-dialog').close('remove');await until(()=>p.$('admin-status').textContent==='Subject deleted.');assert.equal(repository.catalog.subjects.length,0);
 }finally{p.dom.window.close();}
});

test('one confirmed subject deletion removes its chapters and documents while preserving another subject',async()=>{
 const repository=sharedRepository(),p=await page('admin',repository);
 try{
  await connect(p);await addSubject(p,'Keep');await addChapter(p,'Keep chapter');
  const keep=repository.catalog.subjects[0].id;
  await addSubject(p,'Delete');await addChapter(p,'First');
  const file=new File(['%PDF-1.7\n'],'notes.pdf',{type:'application/pdf'});Object.defineProperty(p.$('lesson-file'),'files',{value:[file],configurable:true});p.$('lesson-title').value='Notes';submit(p,'upload-form');await until(()=>p.$('admin-status').textContent==='Published.');
  await addChapter(p,'Second');
  p.$('admin-subjects').querySelectorAll('.remove')[1].click();assert.match(p.$('confirm-message').textContent,/2 chapters and 1 document/);p.$('confirm-dialog').close('remove');
  await until(()=>p.$('admin-status').textContent==='Subject deleted.');assert.deepEqual(repository.catalog.subjects.map(s=>s.id),[keep]);assert.equal(repository.catalog.chapters.length,1);assert.equal(repository.catalog.chapters[0].name,'Keep chapter');assert.equal(repository.documents.size,0);
 }finally{p.dom.window.close();}
});

test('a partial deletion failure refreshes remaining items and never reports success',async()=>{
 const repository=sharedRepository(),p=await page('admin',repository);
 try{
  await connect(p);await addSubject(p,'Science');await addChapter(p,'Chapter');
  const file=new File(['%PDF-1.7\n'],'notes.pdf',{type:'application/pdf'});Object.defineProperty(p.$('lesson-file'),'files',{value:[file],configurable:true});p.$('lesson-title').value='Notes';submit(p,'upload-form');await until(()=>p.$('admin-status').textContent==='Published.');
  repository.rejectAfterSuccessfulPublications(1);
  p.$('admin-subjects').querySelector('.remove').click();p.$('confirm-dialog').close('remove');await until(()=>p.$('admin-status').textContent.startsWith('Deletion stopped.'));
  assert.match(p.$('admin-status').textContent,/Remaining items are shown/);assert.equal(repository.catalog.subjects.length,1);assert.equal(repository.catalog.chapters.length,1);assert.equal(repository.catalog.lessons.length,0);assert.equal(repository.documents.size,0);assert.match(p.$('admin-chapters').textContent,/Chapter/);assert.equal(p.$('admin-refresh').disabled,false);
 }finally{p.dom.window.close();}
});

test('selecting a subject and chapter sets upload destination; file name prefills an editable title',async()=>{
 const repository=sharedRepository(),p=await page('admin',repository);
 try{
  await connect(p);await addSubject(p,'Science');await addChapter(p,'Atoms');const firstSubject=repository.catalog.subjects[0].id,firstChapter=repository.catalog.chapters[0].id;
  await addSubject(p,'Maths');await addChapter(p,'Numbers');assert.equal(p.$('selected-subject').textContent,'Maths');
  p.$('admin-subjects').querySelector('.item-select').click();assert.equal(p.$('selected-subject').textContent,'Science');assert.equal(p.$('selected-chapter').textContent,'Atoms');assert.ok(!p.$('admin-chapters').textContent.includes('Numbers'));
  assert.equal(p.$('upload-form').hidden,true);p.$('show-upload').click();assert.equal(p.$('upload-form').hidden,false);
  const file=new File(['%PDF-1.7\n'],'Atom notes.pdf',{type:'application/pdf'});Object.defineProperty(p.$('lesson-file'),'files',{value:[file],configurable:true});p.$('lesson-file').dispatchEvent(new p.w.Event('change'));assert.equal(p.$('lesson-title').value,'Atom notes');
  p.$('lesson-title').value='Edited title';submit(p,'upload-form');await until(()=>p.$('admin-status').textContent==='Published.');assert.equal(repository.catalog.lessons[0].subjectId,firstSubject);assert.equal(repository.catalog.lessons[0].chapterId,firstChapter);assert.equal(repository.catalog.lessons[0].title,'Edited title');assert.equal(p.$('upload-form').hidden,true);
  p.$('show-upload').click();p.$('cancel-upload').click();assert.equal(p.$('upload-form').hidden,true);assert.equal(p.$('lesson-title').value,'');
 }finally{p.dom.window.close();}
});

test('top subject menu switches complete collections, filters files and supports shared subject URLs',async()=>{
 const repository=sharedRepository();
 repository.catalog.subjects.push({id:'ai',name:'AI'},{id:'statistics',name:'Statistics'},{id:'algebra',name:'Algebra'});
 repository.catalog.chapters.push({id:'foundations',subjectId:'ai',name:'Foundations'},{id:'learning',subjectId:'ai',name:'Machine learning'},{id:'probability',subjectId:'statistics',name:'Probability'},{id:'equations',subjectId:'algebra',name:'Equations'});
 const make=(id,subjectId,chapterId,title,type='pdf')=>({id,subjectId,chapterId,title,type,originalName:id+'.'+type,size:20,uploadedAt:'2026-10-27T10:00:00Z',path:`documents/${subjectId}/${chapterId}/${id}.${type}`,example:true});
 repository.catalog.lessons.push(make('ai-notes','ai','foundations','Course notes'),make('ai-slides','ai','learning','Learning slides','pptx'),make('stats-notes','statistics','probability','Probability notes'));
 const p=await page('student',repository);
 try{
  await until(()=>p.$('subject-nav').children.length===3);
  assert.equal(p.$('course-title').textContent,'AI');assert.equal(p.$('lessons').querySelectorAll('.chapter').length,2);assert.equal(p.$('lessons').querySelectorAll('.lesson-row').length,2);
  assert.equal(p.$('example-notice'),null);assert.match(p.$('lessons').textContent,/Example/);
  p.$('file-filter').value='pdf';p.$('file-filter').dispatchEvent(new p.w.Event('change'));assert.equal(p.$('lessons').querySelectorAll('.lesson-row').length,1);assert.ok(!p.$('lessons').textContent.includes('Learning slides'));
  p.$('subject-nav').querySelectorAll('a')[1].click();assert.equal(p.$('course-title').textContent,'Statistics');assert.match(p.w.location.search,/subject=statistics/);assert.equal(p.$('file-filter').value,'');assert.match(p.$('lessons').textContent,/Probability notes/);assert.ok(!p.$('lessons').textContent.includes('Course notes'));
  assert.equal(p.$('chapter-index').querySelector('a').getAttribute('href'),'#chapter-probability');
  p.$('search').value='absent';p.$('search').dispatchEvent(new p.w.Event('input'));assert.match(p.$('lessons').textContent,/No matches/);assert.equal(p.$('subject-nav').children.length,3,'search does not hide the subject menu');
  p.$('subject-nav').querySelectorAll('a')[2].click();assert.equal(p.$('search').value,'');assert.match(p.$('lessons').textContent,/No resources yet/);
 }finally{p.dom.window.close();}
 const shared=await page('student',repository,'?subject=statistics');try{await until(()=>shared.$('subject-nav').children.length===3);assert.equal(shared.$('course-title').textContent,'Statistics');}finally{shared.dom.window.close();}
});
