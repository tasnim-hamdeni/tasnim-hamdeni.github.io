import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { JSDOM } from "jsdom";
const source = (name) =>
  readFile(new URL("../site/" + name, import.meta.url), "utf8");
const until = async (check) => {
  for (let i = 0; i < 100; i++) {
    if (check()) return;
    await new Promise((r) => setTimeout(r, 5));
  }
  assert.ok(check());
};
async function page(role) {
  const dom = new JSDOM(
      await source(role === "teacher" ? "tasnim/index.html" : "index.html"),
      {
        url:
          "https://tasnim-hamdeni.github.io/" +
          (role === "teacher" ? "tasnim/" : ""),
        runScripts: "outside-only",
      },
    ),
    w = dom.window,
    calls = [];
  const teacherState = {
    year: { id: "year", label: "2026–2027" },
    years: [
      { id: "year", label: "2026–2027", starts: "2026-09-01", active: 1 },
    ],
    courses: [{ id: "ai", name: "AI", archived: 0 }],
    chapters: [
      { id: "chapter", course_id: "ai", name: "Chapter", status: "published" },
    ],
    documents: [],
    students: [],
    enrollments: [],
    announcements: [],
    attendanceSessions: [],
    assignments: [],
    submissions: [],
    submissionFiles: [],
    templates: [],
    sheets: [],
    settings: { timezone: "Africa/Lagos", lateWeight: 1, excused: "exclude" },
    usage: [],
  };
  const studentState = {
    course: { id: "ai", name: "AI" },
    year: { id: "year", label: "2026–2027" },
    student: { firstName: "Student", lastName: "One" },
    chapters: [],
    documents: [],
    announcements: [
      {
        id: "a",
        title: "<img src=x onerror=alert(1)>",
        body: "Message",
        date: "2026-10-29T10:00:00Z",
        read: false,
        attachments: [],
      },
    ],
    assignments: [],
    submissions: [],
    sheets: [{ id: "sheet", title: "Projects" }],
    attendance: { records: [], summaries: [] },
    timezone: "Africa/Lagos",
  };
  Object.assign(w, {
    TextEncoder,
    TextDecoder,
    AbortSignal,
    structuredClone,
    GlobalWorkerOptions: {},
    getDocument: () => ({
      promise: Promise.reject(new Error("No PDF fixture")),
    }),
  });
  Object.defineProperty(w.crypto, "randomUUID", { value: randomUUID });
  w.HTMLDialogElement.prototype.showModal = function () {
    this.open = true;
  };
  w.HTMLDialogElement.prototype.close = function () {
    this.open = false;
    this.dispatchEvent(new w.Event("close"));
  };
  w.localStorage.setItem = () => {
    throw new Error("Credentials must not be saved");
  };
  w.sessionStorage.setItem = w.localStorage.setItem;
  w.signIn = async (...args) => {
    calls.push(["signIn", ...args]);
  };
  w.signOut = async () => {
    calls.push(["signOut"]);
  };
  w.clearSession = () => {};
  w.api = async (path) => {
    calls.push(["api", path]);
    if (path.startsWith("/state")) return structuredClone(teacherState);
    if (path === "/student") return structuredClone(studentState);
    if (path === "/storage") return { connected: false, configured: false };
    if (path === "/sheets/sheet")
      return {
        sheet: {
          id: "sheet",
          title: "Projects",
          columns: [{ id: "topic", label: "Topic", type: "text", options: [] }],
        },
        entries: [],
        canEdit: true,
        group: null,
      };
    throw new Error("Unhandled fixture route");
  };
  w.command = async (action, data) => {
    calls.push(["command", action, data]);
    if (action === "courses.save") {
      teacherState.courses.push({ id: "new", name: data.name });
      return { id: "new" };
    }
    if (action === "announcements.read")
      studentState.announcements[0].read = true;
    return {};
  };
  const script = (await source("classroom.js"))
    .replace(/^import[\s\S]*?;\r?\n/gm, "")
    .replaceAll(
      "import.meta.url",
      JSON.stringify("https://tasnim-hamdeni.github.io/classroom.js"),
    );
  w.eval(script);
  const byText = (text) =>
    [...w.document.querySelectorAll("button")].find(
      (b) => b.textContent === text,
    );
  const submit = async () => {
    w.document.querySelector("input[name=code]").value = "local-fixture";
    w.document
      .querySelector("form")
      .dispatchEvent(
        new w.Event("submit", { bubbles: true, cancelable: true }),
      );
    await until(() => !!byText("Sign out"));
  };
  return { dom, w, calls, byText, submit };
}
test("teacher dashboard adds a course, preserves text safely, and asynchronous buttons do not report false errors", async () => {
  const p = await page("teacher");
  try {
    await p.submit();
    p.byText("+ Add course").click();
    const name = p.w.document.querySelector("dialog input[name=name]");
    name.value = "<script>unsafe</script>";
    p.w.document
      .querySelector("dialog form")
      .dispatchEvent(
        new p.w.Event("submit", { bubbles: true, cancelable: true }),
      );
    await until(
      () =>
        p.w.document.body.textContent.includes("<script>unsafe</script>") &&
        !p.w.document.querySelector("dialog"),
    );
    assert.equal(p.w.document.querySelector("#app script"), null);
    p.byText("Course options").click();
    assert(p.byText("Rename course"));
    p.byText("Close").click();
    await new Promise((r) => setTimeout(r, 20));
    assert.equal(p.w.document.getElementById("status").textContent, "");
    assert(p.calls.some((c) => c[0] === "command" && c[1] === "courses.save"));
  } finally {
    p.dom.window.close();
  }
});
test("teacher tools appear only after opening a course and chapter", async () => {
  const p = await page("teacher");
  try {
    await p.submit();
    assert.equal(
      p.w.document.querySelector("#app h1").textContent,
      "My courses",
    );
    assert.equal(
      p.w.document.querySelector('[aria-label="Teacher tools"]'),
      null,
    );
    assert(
      !p.w.document.querySelector("#app").textContent.includes("Africa/Lagos"),
    );
    assert(!p.byText("+ Upload document"));
    p.w.document.querySelector(".teacher-card").click();
    assert.equal(p.w.document.querySelector("#app h1").textContent, "AI");
    assert(p.byText("+ Add chapter"));
    assert(!p.byText("Rename course"));
    assert(!p.byText("+ Upload document"));
    p.w.document.querySelector(".teacher-chapter-row").click();
    assert.equal(p.w.document.querySelector("#app h1").textContent, "Chapter");
    assert(p.byText("+ Upload document"));
    assert(!p.byText("Move chapter up"));
    p.byText("Chapter options").click();
    assert(p.byText("Move chapter up"));
    p.byText("Close").click();
    p.w.document.querySelector(".teacher-crumbs button").click();
    assert.equal(
      p.w.document.querySelector("#app h1").textContent,
      "My courses",
    );
    p.byText("Settings").click();
    assert(
      [...p.w.document.querySelectorAll("#view > details")].every(
        (d) => !d.open,
      ),
    );
  } finally {
    p.dom.window.close();
  }
});
test("student portal renders project cards, treats announcements as text, and signs out cleanly", async () => {
  const p = await page("student");
  try {
    await p.submit();
    p.byText("Projects").click();
    assert(p.byText("Open project table"));
    assert(!p.w.document.body.textContent.includes("[object HTMLElement]"));
    p.byText("Announcements •").click();
    assert.equal(p.w.document.querySelector("#app img"), null);
    assert(
      p.w.document.body.textContent.includes("<img src=x onerror=alert(1)>"),
    );
    p.byText("Mark as read").click();
    await until(() =>
      p.calls.some((c) => c[0] === "command" && c[1] === "announcements.read"),
    );
    p.byText("Sign out").click();
    await until(() => p.byText("Sign in"));
    assert(p.calls.some((c) => c[0] === "signIn" && c[1] === "student"));
  } finally {
    p.dom.window.close();
  }
});
