# Verification — readable resource room and on-site PDF reader

Checked on 27 October 2026.

## Published site and data

Students: https://tasnim-hamdeni.github.io/

Teacher: https://tasnim-hamdeni.github.io/tasnim/

Website source commit: 0ef3acfd2ca5dab4bffca59bed4bbbf9f769292a

Example catalog commit: 6b1f27409a40a8c675ca8804efd64d7090f5c1d7

GitHub Pages build: 40597481184, completed successfully.

The connected account was verified as tasnim-hamdeni. Existing destination repositories were inspected and unrelated files were preserved. The initial catalog was empty. The owner explicitly requested AI, Statistics and Algebra, example chapters and blank PDF files. The final catalog has 3 subjects, 9 chapters and 18 PDFs, all marked example=true. Each PDF is a valid blank A4 page, verified with pypdf and rendered with Poppler.

## Browser verification

This update uses a navy full-width subject band, large subject buttons, gold selection, dark text and larger type on a blue-gray background. Student and teacher phone layouts were reviewed at 390px. The public site was opened after the successful Pages deployment. Existing data and server code were preserved.

The redesigned public website was opened and visually checked. The top menu switches subject collections; subject links retain a shareable URL. Chapter search, file-type filtering, helpful no-match states and reset-on-subject-change were checked. A PDF downloaded through the student button matched the source PDF byte-for-byte. PDF View now links to the website’s viewer.html, rather than GitHub. The live reader rendered the actual public PDF as a canvas (Page 1 of 1), with no browser console errors. Zoom and download were checked. The downloaded bytes matched the original blank example. Mozilla PDF.js 6.4.299 is bundled with its license, CMaps, fonts and WebAssembly decoders; it does not rely on a browser PDF plugin.

Student and teacher layouts were reviewed in 390px-wide phone frames. The student menu remains available, resource actions wrap, and teacher controls fit the narrow layout. Desktop and live screenshots are in artifacts/ (excluded from the source ZIP).

Tasnim’s actual production page was tested with its existing access code. A browser connection failure exposed an unnecessary X-GitHub-Api-Version header in the proxy transport; the client now sends only the CORS-permitted Authorization and Content-Type headers. A regression test covers this behavior.

A requested blank example PDF was uploaded through the actual teacher form and published successfully (upload commit c930427c7b9eed2d922655c42e652aca3d0635fe). An independent student tab fetched it from the public catalog and displayed it. Its title and example flag were subsequently normalized alongside the other samples. This verifies real browser-to-server-to-GitHub publishing, beyond the earlier read/write-only check.

Actual subject and chapter creation were tested using clearly named temporary example entries. Cancelling removal preserved the chapter; confirming removal deleted the empty chapter and then its empty subject. The temporary entries were removed, leaving exactly the three requested subjects. Occupied parents retain the existing protection: documents must be removed before a chapter, chapters before a subject. Teacher sign-out was checked after testing.

## Automated checks

27 website/catalog/DOM/PDF reader tests passed. They cover public access, schema and file validation, immutable updates, concurrency conflicts, safe migration, atomic file/catalog publication, failed and ambiguous operations, protected deletion, literal HTML titles, access-code proxy headers, top-menu navigation, file filters and subject deep links.

The unchanged authentication service previously passed 8 server tests, including sessions, expiry/revocation, rate limits, encrypted credential storage, restricted repository operations and safe redirect handling. Total: 35 passing checks, including the 8 unchanged service checks from the prior deployment. The two new reader tests cover multi-page navigation, zoom, literal titles, missing IDs and invalid/incomplete files.

All 16 checked deployed runtime files (including PDF.js and its worker) match local source and return HTTP 200. The real public catalog validates without credentials. Deployed modules also passed DOM-emulator checks. No credential or access code is included in the source or ZIP.

## Limits and maintenance

A physical second device was not used; cross-visitor visibility was checked with a separate student browser tab reading the public catalog. The example PDFs are deliberately blank and are not teaching material. Tasnim can remove them and upload real courses.

The existing repository credential remains encrypted on the server. A token that was shared in chat should be replaced using the private owner setup page. Tasnim’s daily use requires only the access code.
