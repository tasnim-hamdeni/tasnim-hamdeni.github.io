# Verification — access-code sign-in

Checked on 26 October 2026.

## Published components

Students: https://tasnim-hamdeni.github.io/

Teacher: https://tasnim-hamdeni.github.io/tasnim/

Access service and owner setup: https://tasnim-classroom-service.beigepear256.chatgpt.site/

Website source commit: 9a530e63cd8fe3a0c3d2c9543e777a0369fdc2d8

Data documentation commit: 02f3e911721d2538eff6630db994d11a1d1687d6

Service source commit: d70f290a99f597d3ba482227855b92357d8f0c70

Service deployment: appgdep_6adfce40ea9081919a2022eebf3639d8 (succeeded, runtime environment revision 1)

The server was built using the hosting provider’s remote build after local dependency downloads repeatedly timed out. Source was pushed before saving and deployment. The D1 schema migration was applied; live session creation and revocation prove the authentication tables are usable.

## Passed checks

- 23 website/catalog/DOM tests and 8 server tests passed.
- Server tests cover incorrect codes, lockouts, random session issuance, hashed session storage, expiry and revocation, encrypted repository credential storage, restricted GitHub paths, non-forced branch updates, origin checks and ambiguous upstream failure handling.
- The real access code was accepted by the deployed service. Its temporary test session was revoked. Neither the code nor session was written to source files.
- The owner setup page and its four script/CSS assets returned HTTP 200. CORS preflight for the GitHub Pages origin returned 204; unauthenticated publishing requests returned 401.
- All 11 deployed website runtime files match the delivered source and return HTTP 200.
- The real public catalog loads without credentials and contains no fake lessons.
- The deployed student and teacher modules passed DOM-emulator checks. The teacher page contains an access-code field and no GitHub-token instructions. The workspace remains disabled until sign-in and storage connection succeed.

## Storage connection completed

The owner-provided credential was connected to the service through hidden input over TLS. It is encrypted in the server database and never included in source files, command arguments, or this ZIP.

Live checks passed after connection: access-code sign-in, authenticated repository reads, protected branch write access, and session revocation. Write access was verified by updating the branch to its existing SHA, without changing lessons or catalog contents. Tasnim can now use her code-only page.

The publishing proxy was corrected to use the hosting runtime’s supported manual redirect mode. Redirect responses are rejected, so credentials cannot be forwarded to a different destination. A regression test covers this behavior. Reference: https://developers.cloudflare.com/workers/runtime-apis/request/

Because the owner supplied the credential in chat, replacing it through the private owner setup page is recommended. Never put the replacement in chat.

No real teacher document was supplied, so no real upload or physical second-device upload test has been performed. No fictional lessons were published. The public GitHub catalog and original document paths are preserved. A graphical browser review remains unavailable in this session; DOM tests do not verify visual layout.
