# Verification report — 25 October 2026

## Published result

**Published and opened successfully:** https://tasnim-hamdeni.github.io/

Admin: https://tasnim-hamdeni.github.io/admin.html

The existing implementation was reused. The actual public repositories are:

- `tasnim-hamdeni/tasnim-hamdeni.github.io` (ID 1433180751), website commit `51ae66daa653b1eb90d6776c38156c489c042cb4`.
- `tasnim-hamdeni/tasnim-lesson-data` (ID 1433181498), data commit `d36b779ecdc75425bef42027eb453074439d2156`.

The signed-in GitHub browser account was freshly verified as `tasnim-hamdeni`. The repository-name availability checks passed before creation. Both repositories were created public with default branch main, and only their newly initialized README files were replaced with project documentation. Source files, repository markers, the real empty catalog, and document-folder instructions were committed through that authenticated browser session.

GitHub's Pages settings show **Deploy from a branch → main → / (root)**, no custom domain, enforced HTTPS, and the live URL above. A successful Pages deployment was visible before the public browser check. No GitHub CLI authentication or token was used to publish.

## Live browser and public checks

- Opened the actual student URL and admin URL in the browser.
- Student page loaded the public GitHub catalog successfully without sign-in: **0 subjects, 0 lessons**. Its welcoming empty state appeared, rather than a connection error.
- Clicked Refresh library and confirmed the catalog loaded again.
- Verified student search displays the no-match state and returns to the normal empty state after clearing the query.
- Verified admin editing/upload/removal controls are disabled while disconnected.
- Verified invalid-token input is rejected and cleared without attempting a GitHub write.
- Expanded and read the deployed token instructions: resource owner tasnim-hamdeni, only tasnim-lesson-data, Contents: Read and write, automatic Metadata: Read-only, and other permissions left unset.
- Confirmed the public-content warning and 50 MiB upload limit appear before any upload.
- Ran `node scripts/verify-public.mjs`: all nine runtime files returned **HTTP 200** and matched local source, normalizing line endings/trailing whitespace: index.html, admin.html, styles.css, config.js, core.js, github.js, student.js, admin.js, assets/mark.svg.
- Read the public raw catalog from the separate repository, validated its schema, and confirmed it is empty. The documents folder contains explanatory documentation, not sample lessons.

Live student/admin screenshots are saved locally under `artifacts/`; they are excluded from the source ZIP.

## Automated checks

`node --test tests/library.test.mjs`: **15 passed, 0 failed**, rerun after changing the owner configuration to tasnim-hamdeni.

Coverage includes empty/immutable catalog changes; duplicate subjects and IDs; invalid paths, sizes, dates, and missing subjects; occupied-subject protection; stale deletion handling; PDF extension/MIME/signature and upload limit; PPTX archive-directory checks; public/private repository handling; browser fetch binding; non-forced branch updates; conflict retry preserving another session's edit; concurrent subject deletion; atomic document/catalog deletion; atomic upload/catalog publication; blob reuse during retries; failed uploads without catalog writes; ambiguous final-update responses; and credential-free public reads.

Syntax checks passed for production JavaScript, the deployment script, the preview/QA servers, and the public verification script.

## Earlier isolated browser checks

These checks used production HTML/CSS/JavaScript with API origins substituted by the loopback-only `tests/qa-server.mjs`. It displayed LOCAL QA ONLY and held all test data only in server memory. Production files contain no mock-upload behavior.

Verified adding/removing subjects; PDF publication; PPTX-format publication; a separate student tab reading the changed shared catalog; search/filter/no-match behavior; literal HTML-like title rendering; lesson deletion confirmation and cancellation; protection against deleting occupied subjects; and disconnect clearing the connection and disabling editing.

The downloaded PDF matched its uploaded test fixture byte-for-byte (SHA-256 `B083C4D9F8F5B9BD009C6999E44CC475CBC7FBB92F478A1D5B61F76BEA4AB793`). Disposable fixtures and test subjects are not in the public catalog or source ZIP.

Desktop layouts were visually inspected. Student and admin phone layouts were checked in 390px embedded viewports (375px content width after the scrollbar). Both had scrollWidth equal to clientWidth, 375px. Decorative-art overflow found during QA was corrected. The isolated QA and preview servers were stopped after testing.

## Account protection and connection status

The user explicitly authorized renaming the university-email account from chamseddinehamdeni-tech to tasnim-hamdeni, accepting the change to its existing Test Pages address. GitHub confirmed the rename, and a fresh settings page verified its sole associated email was the university address. The existing Test repository's files and publishing configuration were left unchanged.

The original connected **IMS-Tunis** account was used for read-only inspection only. Its seven repositories remain listed. No repository writes, deletions, or publication were performed there.

The user completed the new account's initial identity authorization for ChatGPT Codex Connector. Its separate installation page is prepared with **Only select repositories** and exactly the two new repositories selected. **Install & Authorize remains pending user approval**; the existing connection is preserved. The default connector last reported IMS-Tunis, and it was not used for this deployment. This connection approval is separate from the site's public operation and Tasnim's token-based admin access.

## Remaining live verification

No real teacher token was requested, created, read, or used. A real upload and visibility from another physical device have **not** been verified live. Tasnim should create her own fine-grained token scoped only to the data repository, publish her own subject/document from admin.html, and verify it from a second device. Local tests establish the upload implementation; they do not substitute for that final check with her credentials and content.
