# Verification — access-code sign-in

Checked on 26 October 2026.

## Published components

Students: https://tasnim-hamdeni.github.io/

Teacher: https://tasnim-hamdeni.github.io/tasnim/

Access service and owner setup: https://tasnim-classroom-service.beigepear256.chatgpt.site/

Website source commit: 9a530e63cd8fe3a0c3d2c9543e777a0369fdc2d8

Data documentation commit: 02f3e911721d2538eff6630db994d11a1d1687d6

Service source commit: bcad29f47cd7f40f672b5b7f209dc356a8f0687f

Service deployment: appgdep_6adfc85e1a488191a14842540f93061e (succeeded, runtime environment revision 1)

The server was built using the hosting provider’s remote build after local dependency downloads repeatedly timed out. Source was pushed before saving and deployment. The D1 schema migration was applied; live session creation and revocation prove the authentication tables are usable.

## Passed checks

- 23 website/catalog/DOM tests and 7 server tests passed.
- Server tests cover incorrect codes, lockouts, random session issuance, hashed session storage, expiry and revocation, encrypted repository credential storage, restricted GitHub paths, non-forced branch updates, origin checks and ambiguous upstream failure handling.
- The real access code was accepted by the deployed service. Its temporary test session was revoked. Neither the code nor session was written to source files.
- The owner setup page and its four script/CSS assets returned HTTP 200. CORS preflight for the GitHub Pages origin returned 204; unauthenticated publishing requests returned 401.
- All 11 deployed website runtime files match the delivered source and return HTTP 200.
- The real public catalog loads without credentials and contains no fake lessons.
- The deployed student and teacher modules passed DOM-emulator checks. The teacher page contains an access-code field and no GitHub-token instructions. The workspace remains disabled until sign-in and storage connection succeed.

## Remaining owner setup

The server has not been given a GitHub repository credential. A valid code therefore reports that one-time owner setup is needed; an authenticated library request returns HTTP 503 rather than falsely claiming a working connection. Uploading real lessons is not ready until the owner completes the storage connection on the service page. Tasnim never needs to create or paste that credential.

The owner must create an expiring fine-grained GitHub token restricted to tasnim-lesson-data, Contents: Read and write, and enter it directly in the private-input owner setup form. It will be encrypted on the server. No real GitHub token was requested in chat, created, read or saved during the build.

No real teacher upload or physical second-device upload test has been performed. The public GitHub catalog and original document paths have been preserved. A graphical browser review is unavailable in this session; DOM tests do not verify visual layout.
