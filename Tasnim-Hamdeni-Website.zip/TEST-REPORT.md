# Verification — chapter update

Checked on 26 October 2026.

## Automated checks

`npm test`: **23 tests passed**.

Tests cover subject/chapter creation, duplicate handling, safe version 1 migration, chapter-to-subject relationships, PDF/PPTX validation, file limits, atomic file/catalog commits, concurrent edits and parent deletion, failed uploads, ambiguous publication responses, and document deletion.

Three DOM interaction tests execute the actual application modules in jsdom with an isolated, shared mock Git API. They verify connecting, creating a subject and chapter, uploading a document, reading it from an independent student document, search/filter, literal HTML titles, blocked parent deletion, cancellation/confirmation, selection synchronization and disconnect. They never contact GitHub or publish test content.

Syntax checks passed for production JavaScript and deployment scripts. Both HTML pages have unique IDs, valid form labels and existing local asset paths. Student pages contain no teacher links. Production JavaScript contains no localStorage/sessionStorage, innerHTML or console logging.

## Publication

Student URL: https://tasnim-hamdeni.github.io/

Teacher URL: https://tasnim-hamdeni.github.io/tasnim/

Website source commit: 75d242ec2f9031b29b1029e1d2cf164e24e9cfc7

Data documentation commit: e07fc2f34aa0ebdf5023657680567a01b130c330

GitHub write access was verified as tasnim-hamdeni (281890898). GitHub Pages successfully published the source update (Actions run 40401635571). Both student and teacher URLs return HTTP 200. All 10 deployed runtime files match the source, and the public catalog validates without credentials. The deployed application modules also passed DOM-emulator checks: the student page fetched the real public catalog, the teacher page starts with editing disabled, token instructions identify the single data repository, and invalid token input is cleared. Public verification results are recorded in deployment-status.json. No unrelated repository was changed. The existing public catalog and document paths were preserved; version 1 catalogs upgrade safely on the next teacher edit.

## Verification limits

A fresh visual browser check is unavailable: the browser interaction tool is not available in this session. DOM tests do not measure visual layout. Public HTTP/source checks and opening the published pages verify serving and content, rather than graphical rendering.

No real teacher token was requested, created, read or saved. No real teacher upload or physical second-device test has been performed. Tasnim must create the repository-scoped token and enter it directly on /tasnim/ to upload her own content.
