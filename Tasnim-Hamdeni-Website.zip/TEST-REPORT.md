# Verification — minimal course resources and simpler teacher tools

Checked on 28 October 2026.

Students: https://tasnim-hamdeni.github.io/

Teacher: https://tasnim-hamdeni.github.io/tasnim/

Website source: 5804f922db04199db08758bffed9b358719e7cd7

GitHub Pages run: 40600669214, completed successfully.

## Changes

Removed the promotional descriptions, resource-room labels, decorative quotation, example explanation banner and footer slogan. Kept subject navigation, chapter resources, search, file filters and PDF/download controls. Requested blank examples retain a small Example badge.

The teacher page now has one subject list, the selected subject’s chapters, and the selected chapter’s documents. Add subject, Add chapter and Add document are explicit actions. The file name prefills an editable document title. Duplicate destination selectors were removed. Phone navigation includes links back to subjects and chapters.

Deleting a subject or chapter requires one confirmation naming it and counting its contents. Confirmed documents are removed first, then chapters, then the subject. Each operation retains the existing non-forced concurrent-update protection. Newly added concurrent contents block parent deletion. An interrupted deletion refreshes the catalog and reports the failure; it does not claim success. Completed earlier removals are not rolled back.

## Checks

29 website/catalog/DOM/PDF-reader tests pass. Coverage includes confirmed and cancelled recursive deletion, preserving another subject, partial deletion failure, upload destination selection, automatic titles, publication failures, concurrent updates, file validation, literal HTML titles and PDF viewing/navigation. The unchanged service previously passed 8 authentication/proxy tests.

The isolated browser QA library was used to add a subject, add a chapter, upload a blank PDF, cancel deletion, and confirm deletion of the test subject with its contents. All mutations were confined to the temporary local library. Student and signed-in teacher layouts were reviewed in 390px phone frames.

The actual published student and teacher pages were opened. Live code sign-in, subject selection, opening/cancelling the upload form, deletion confirmation/cancel and sign-out passed. No live content was added or removed during these checks. All 16 checked public runtime files match local source and return HTTP 200; deployed modules also pass DOM-emulator checks.

The live public catalog validates with 3 subjects, 10 chapters and 19 documents. It was preserved, including the owner’s additional chapter and document. Its observed commit is e8e2c6278700d07b36aa3f364f938a9712942e56. The ZIP contains only the requested starter examples, not a backup of later user uploads; never replace a live catalog with that starter.

Screenshots are saved under artifacts/ and excluded from the source ZIP. No credentials are included in source or the ZIP. Backend code and unrelated repositories were unchanged. No remaining setup is required for this update.
