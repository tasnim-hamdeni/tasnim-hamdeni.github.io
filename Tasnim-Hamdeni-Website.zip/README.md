# Tasnim Hamdeni — lesson library

**Published and opened successfully on 25 October 2026:** https://tasnim-hamdeni.github.io/

- Student website: https://tasnim-hamdeni.github.io/
- Teacher administration: https://tasnim-hamdeni.github.io/admin.html
- Website repository: https://github.com/tasnim-hamdeni/tasnim-hamdeni.github.io
- Public lesson-data repository: https://github.com/tasnim-hamdeni/tasnim-lesson-data

GitHub Pages publishes the website from **main → / (root)** with HTTPS and no custom domain. Both repositories are public. The existing HTML/CSS/JavaScript implementation was reused. The catalog is genuinely empty, with no fictional lessons or sample uploads.

## Tasnim's remaining setup: upload token

Students need no account or token. To manage content, Tasnim creates her own fine-grained GitHub personal access token:

1. Sign in as **tasnim-hamdeni**. Open **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**: https://github.com/settings/personal-access-tokens/new
2. Choose resource owner **tasnim-hamdeni**, a short expiration, and **Only select repositories → tasnim-lesson-data**.
3. Grant **Contents: Read and write**. GitHub automatically includes **Metadata: Read-only**. Leave other repository, account, Pages, workflow, and administration permissions unset.
4. Generate the token yourself. Paste it directly into the password field on the admin page and select **Connect**. Never send it in chat or put it in source files.
5. Add real subjects, then upload PDF/PPTX lessons, up to **50 MiB (52,428,800 bytes)** per file. Select **Disconnect** when finished.

The token stays only in page memory and is cleared on disconnect, reload, navigation, or closing. It is never saved to localStorage/sessionStorage, configuration, URLs, logs, commits, or this ZIP. GitHub authenticates each write. The browser cannot enforce the token's scope, so select only the data repository during token creation.

**All lessons and catalog metadata are public. Never upload private student information.** Removal deletes current content, while Git history, caches, and downloaded copies may retain it. Publish only material you have permission to share. Revoke exposed or expired tokens in GitHub.

## Shared lessons and safety

`catalog.json` in the data repository stores subjects, lesson titles, types, sizes, and dates. Documents go in `documents/<subject-uuid>/<lesson-uuid>.pdf` or `.pptx`. Students on other devices see published lessons after refreshing; GitHub's public cache can take a few minutes to update. Uploading lessons requires no website redeployment.

The admin validates the extension, MIME when available, and PDF/PPTX signatures. Titles and filenames render as text. It commits document additions/deletions and catalog updates together, updates the branch with `force: false`, and retries concurrent edits against the latest catalog. Failed or unconfirmed publication is reported without claiming success. Removing lessons requires confirmation; occupied subjects are protected from deletion.

## Verification performed

- Opened the actual public student and admin URLs in a browser.
- Confirmed the live student page reads the public catalog without credentials: 0 subjects and 0 lessons.
- Checked live refresh, search/no-match state, disabled admin editing while disconnected, invalid-token rejection, and the expanded token instructions.
- Verified all nine public runtime files return HTTP 200 and match the delivered source, normalizing line endings/trailing whitespace.
- All **15 automated tests pass**. Earlier isolated browser tests exercised PDF/PPTX publication, separate student-tab visibility, download integrity, removal/cancellation, and disconnect. See `TEST-REPORT.md` for details.

A real teacher-token upload and visibility on another physical device remain for Tasnim to verify with her own content. No teacher token or sample lesson was used during deployment.

## Separate Codex connection

The user approved the initial identity authorization for **tasnim-hamdeni**. GitHub's additional **Install & Authorize** repository-access page is prepared with only the two new repositories selected and still awaits the user's final approval. The original connection remains intact. This extra Codex approval is for future assistant access; it is **not required for students or for Tasnim's token-based admin page**.

The renamed account's existing **Test** repository was preserved. The user explicitly accepted the change to its former Pages address. No repository writes were performed against the original **IMS-Tunis** account or its repositories.

## Source and maintenance

- `site/`: complete deployed website source.
- `lesson-data/`: empty catalog, repository marker, README, and public document-folder instructions.
- `scripts/deploy.mjs`: optional account-checked GitHub CLI setup/redeployment. It refuses unrelated destinations, preserves existing marked data, and never force-pushes.
- `scripts/preview.mjs`: local HTTP preview.
- `scripts/verify-public.mjs`: read-only public-source/catalog verification.
- `scripts/package-source.py`: builds and checks the ZIP.
- `tests/`: automated checks and a clearly labeled local-only diagnostic server.
- `deployment-status.json`: actual repositories, commits, published URL, and pending connection status.

No package installation is needed for the website:

```powershell
node scripts/preview.mjs
# Open http://127.0.0.1:4173
node --test tests/library.test.mjs
node scripts/verify-public.mjs
```

For optional future CLI deployment, authenticate GitHub CLI as **tasnim-hamdeni**, then run `node scripts/deploy.mjs`. The script checks the account before writing. CLI authentication was not needed for this browser-based deployment. The original account must never be used as a deployment target.

The ZIP contains no credentials, private student information, sample lessons, generated test documents, Git history, or dependencies.
