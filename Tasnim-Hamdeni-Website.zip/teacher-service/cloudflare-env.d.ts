declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    ACCESS_CODE?: string;
    TOKEN_KEY?: string;
    BUCKET?: R2Bucket;
  }
}
