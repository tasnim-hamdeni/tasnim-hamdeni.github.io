# Tasnim classroom access service

The public student website stays at https://tasnim-hamdeni.github.io/ and teacher tools at /tasnim/. This backend checks the teacher access code, issues 8-hour memory-only sessions, rate-limits attempts, and forwards a narrow set of publishing operations to tasnim-hamdeni/tasnim-lesson-data.

The owner setup page connects a fine-grained GitHub token once. It is encrypted at rest with AES-GCM using a server runtime secret and is never returned to browsers. Tasnim does not need a GitHub account or token for daily use. Public lessons and the catalog remain in GitHub.

Runtime secret names (values must never be committed): ACCESS_CODE, TOKEN_KEY. Change ACCESS_CODE using the Sites runtime environment settings and redeploy. TOKEN_KEY is a 32-byte key encoded as hexadecimal. Rotating it requires reconnecting the repository credential. Sessions expire after 8 hours; sign-out revokes the session. The code is never embedded in the GitHub Pages files or ZIP.

This service uses the Sites Vinext starter and a D1 database for encrypted connection settings, session digests and rate-limit counters. Database migrations are under drizzle/. No lesson content is stored in D1.

Node.js 22.13 or newer is required for local build and service tests. Install with npm ci, generate new schema migrations with npm run db:generate, and build through the Sites workflow. The site is configured using .openai/hosting.json. Never replace or guess its project_id.
