# Tasnim Classroom backend

Frontend: https://tasnim-hamdeni.github.io/ - Teacher: https://tasnim-hamdeni.github.io/tasnim/
API: https://tasnim-classroom-service.chamseddine.chatgpt.site/api/lms/

The Worker checks teacher/student codes, issues eight-hour bearer sessions, and authorizes every database and file request. Sessions remain in browser memory. Only SHA-256 digests of long random student codes and sessions are stored. Every LMS record has a teacher owner; only Tasnim is provisioned in this version.

D1 holds private classroom records. Google Drive holds new files privately, using only drive.file permission. OAuth client credentials and refresh tokens are AES-GCM encrypted in the existing settings table; browsers cannot retrieve them. The owner connects Drive once in Teacher > Settings. No Google account or token is needed by students or in Tasnim's daily workflow.

The original GitHub catalog is imported idempotently through teacher-only POST /api/lms/import-legacy. Historical GitHub documents remain public; new private uploads do not enter GitHub. Original /api/session, /api/connection, and the narrow GitHub proxy remain for compatibility.

Runtime secret names: ACCESS_CODE, TOKEN_KEY. Never commit values. TOKEN_KEY is a 32-byte AES key encoded as hexadecimal; rotating it requires reconnecting encrypted credentials. Changed enrollment, code versions, active years, and active flags invalidate student sessions. Use stronger teacher authentication before broader production rollout.

Email delivery, annual code-renewal scheduling, automatic annual deletion, and daily backups are disabled as agreed. Manual academic years, individual code regeneration, exports, and retention flags are available. Removing a chapter/resource hides it and preserves historical file metadata; removing a submission file calls Drive's delete API. Provider backup retention is outside application control.

Development: Node 24 recommended (node:sqlite is used by integration tests). Run node --test service.test.mjs tests/lms.test.mjs. Publish with the Sites workflow and the existing ID in .openai/hosting.json. D1 migrations under drizzle/ are additive. Never regenerate an already applied migration. Use the schema generator to maintain declarations, then generate a new migration for later changes.

Storage, authorization, SQL repository, domain commands, and transport are separate modules. Teacher JSON export excludes sessions and OAuth credentials. See the ZIP migration guide for PHP/MySQL migration.
