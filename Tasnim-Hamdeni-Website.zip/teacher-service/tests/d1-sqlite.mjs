import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
export function database(){
 const sqlite=new DatabaseSync(':memory:');
 for(const migration of ['0000_classroom_access.sql','0001_lms_platform.sql']){
  // The original migration name is discovered by the caller when needed.
  try{sqlite.exec(readFileSync(new URL('../drizzle/'+migration,import.meta.url),'utf8'));}catch(e){if(e.code==='ENOENT'&&migration.startsWith('0000')){sqlite.exec('CREATE TABLE settings (key TEXT PRIMARY KEY,value TEXT NOT NULL); CREATE TABLE sessions(digest TEXT PRIMARY KEY,expires INTEGER NOT NULL); CREATE TABLE login_windows(key TEXT PRIMARY KEY,attempts INTEGER NOT NULL,reset_at INTEGER NOT NULL);');}else throw e;}
 }
 const DB={prepare(sql){return {args:[],bind(...args){return {...this,args};},async first(){return sqlite.prepare(sql).get(...this.args)||null;},async all(){return {results:sqlite.prepare(sql).all(...this.args)};},async run(){const result=sqlite.prepare(sql).run(...this.args);return {success:true,meta:{changes:Number(result.changes)}};}};},async batch(statements){sqlite.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}},sqlite};
 return DB;
}
