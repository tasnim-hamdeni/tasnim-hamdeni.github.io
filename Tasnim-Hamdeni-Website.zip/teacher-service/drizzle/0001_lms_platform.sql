CREATE TABLE `lms_announcement_reads` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`announcement_id` text NOT NULL,
	`enrollment_id` text NOT NULL,
	`read_at` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_announcement_reads_unique_0` ON `lms_announcement_reads` (`announcement_id`,`enrollment_id`);
--> statement-breakpoint
CREATE TABLE `lms_announcements` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`year_id` text NOT NULL,
	`title` text NOT NULL,
	`body` text NOT NULL,
	`course_ids` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`publish_at` text,
	`attachments` text DEFAULT '[]' NOT NULL,
	`created` text NOT NULL,
	`updated` text NOT NULL
);

--> statement-breakpoint
CREATE INDEX `lms_announcements_indexes_0` ON `lms_announcements` (`teacher_id`,`year_id`);
--> statement-breakpoint
CREATE TABLE `lms_assignments` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`course_id` text NOT NULL,
	`year_id` text NOT NULL,
	`title` text NOT NULL,
	`body` text DEFAULT '' NOT NULL,
	`deadline` text,
	`status` text DEFAULT 'draft' NOT NULL,
	`max_file_bytes` integer DEFAULT 10485760 NOT NULL,
	`max_total_bytes` integer DEFAULT 52428800 NOT NULL,
	`allow_late` integer DEFAULT 0 NOT NULL,
	`allow_replace` integer DEFAULT 1 NOT NULL,
	`groups` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE INDEX `lms_assignments_indexes_0` ON `lms_assignments` (`teacher_id`,`year_id`,`course_id`);
--> statement-breakpoint
CREATE TABLE `lms_attendance_records` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`session_id` text NOT NULL,
	`student_id` text NOT NULL,
	`status` text NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`updated` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_attendance_records_unique_0` ON `lms_attendance_records` (`session_id`,`student_id`);
--> statement-breakpoint
CREATE TABLE `lms_attendance_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`course_id` text NOT NULL,
	`year_id` text NOT NULL,
	`date` text NOT NULL,
	`time` text DEFAULT '' NOT NULL,
	`title` text DEFAULT '' NOT NULL,
	`finalized` integer DEFAULT 0 NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`created` text NOT NULL,
	`write_token` text DEFAULT '' NOT NULL
);

--> statement-breakpoint
CREATE INDEX `lms_attendance_sessions_indexes_0` ON `lms_attendance_sessions` (`teacher_id`,`year_id`,`course_id`);
--> statement-breakpoint
CREATE TABLE `lms_chapters` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`course_id` text NOT NULL,
	`name` text NOT NULL,
	`position` integer DEFAULT 0 NOT NULL,
	`status` text DEFAULT 'hidden' NOT NULL,
	`publish_at` text,
	`deleted` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE INDEX `lms_chapters_indexes_0` ON `lms_chapters` (`teacher_id`,`course_id`);
--> statement-breakpoint
CREATE TABLE `lms_courses` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`year_id` text NOT NULL,
	`name` text NOT NULL,
	`position` integer DEFAULT 0 NOT NULL,
	`archived` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE INDEX `lms_courses_indexes_0` ON `lms_courses` (`teacher_id`,`year_id`);
--> statement-breakpoint
CREATE TABLE `lms_documents` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`chapter_id` text NOT NULL,
	`file_id` text NOT NULL,
	`title` text NOT NULL,
	`status` text DEFAULT 'hidden' NOT NULL,
	`publish_at` text,
	`position` integer DEFAULT 0 NOT NULL,
	`example` integer DEFAULT 0 NOT NULL,
	`deleted` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE INDEX `lms_documents_indexes_0` ON `lms_documents` (`teacher_id`,`chapter_id`);
--> statement-breakpoint
CREATE INDEX `lms_documents_indexes_1` ON `lms_documents` (`teacher_id`,`file_id`);
--> statement-breakpoint
CREATE TABLE `lms_enrollments` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`student_id` text NOT NULL,
	`year_id` text NOT NULL,
	`course_id` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`code_hash` text NOT NULL,
	`code_version` integer DEFAULT 1 NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_enrollments_unique_0` ON `lms_enrollments` (`student_id`,`year_id`);
--> statement-breakpoint
CREATE UNIQUE INDEX `lms_enrollments_unique_1` ON `lms_enrollments` (`code_hash`);
--> statement-breakpoint
CREATE INDEX `lms_enrollments_indexes_0` ON `lms_enrollments` (`teacher_id`,`year_id`,`course_id`);
--> statement-breakpoint
CREATE TABLE `lms_exceptions` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`parent_id` text NOT NULL,
	`enrollment_id` text NOT NULL,
	`closes_at` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_exceptions_unique_0` ON `lms_exceptions` (`parent_id`,`enrollment_id`);
--> statement-breakpoint
CREATE TABLE `lms_files` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`category` text NOT NULL,
	`year_id` text NOT NULL,
	`course_id` text NOT NULL,
	`parent_id` text NOT NULL,
	`enrollment_id` text,
	`name` text NOT NULL,
	`mime` text NOT NULL,
	`size` integer NOT NULL,
	`provider` text NOT NULL,
	`storage_key` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE INDEX `lms_files_indexes_0` ON `lms_files` (`teacher_id`,`category`,`year_id`);
--> statement-breakpoint
CREATE INDEX `lms_files_indexes_1` ON `lms_files` (`teacher_id`,`parent_id`,`status`);
--> statement-breakpoint
CREATE TABLE `lms_group_memberships` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`parent_id` text NOT NULL,
	`group_id` text NOT NULL,
	`enrollment_id` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_group_memberships_unique_0` ON `lms_group_memberships` (`parent_id`,`enrollment_id`);
--> statement-breakpoint
CREATE INDEX `lms_group_memberships_indexes_0` ON `lms_group_memberships` (`teacher_id`,`group_id`,`enrollment_id`);
--> statement-breakpoint
CREATE TABLE `lms_groups` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`parent_id` text NOT NULL,
	`kind` text NOT NULL,
	`course_id` text NOT NULL,
	`year_id` text NOT NULL,
	`owner_enrollment_id` text NOT NULL,
	`member_ids` text NOT NULL,
	`invite_hash` text NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_groups_unique_0` ON `lms_groups` (`invite_hash`);
--> statement-breakpoint
CREATE INDEX `lms_groups_indexes_0` ON `lms_groups` (`teacher_id`,`parent_id`);
--> statement-breakpoint
CREATE TABLE `lms_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`kind` text NOT NULL,
	`job_key` text NOT NULL,
	`payload` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`next_run` text NOT NULL,
	`result` text DEFAULT '{}' NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_jobs_unique_0` ON `lms_jobs` (`job_key`);
--> statement-breakpoint
CREATE TABLE `lms_oauth_states` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`verifier` text NOT NULL,
	`expires` integer NOT NULL,
	`provider` text DEFAULT 'onedrive' NOT NULL
);

--> statement-breakpoint
CREATE TABLE `lms_project_entries` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`sheet_id` text NOT NULL,
	`enrollment_id` text NOT NULL,
	`member_ids` text DEFAULT '[]' NOT NULL,
	`values_json` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`deleted` integer DEFAULT 0 NOT NULL,
	`updated` text NOT NULL,
	`group_id` text
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_project_entries_unique_0` ON `lms_project_entries` (`sheet_id`,`enrollment_id`);
--> statement-breakpoint
CREATE TABLE `lms_project_history` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`entry_id` text NOT NULL,
	`actor_id` text NOT NULL,
	`before_json` text NOT NULL,
	`after_json` text NOT NULL,
	`revision` integer NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_project_history_unique_0` ON `lms_project_history` (`entry_id`,`revision`);
--> statement-breakpoint
CREATE INDEX `lms_project_history_indexes_0` ON `lms_project_history` (`teacher_id`,`entry_id`);
--> statement-breakpoint
CREATE TABLE `lms_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`role` text NOT NULL,
	`student_id` text,
	`enrollment_id` text,
	`code_version` integer,
	`expires` integer NOT NULL
);

--> statement-breakpoint
CREATE TABLE `lms_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`value` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_settings_unique_0` ON `lms_settings` (`teacher_id`);
--> statement-breakpoint
CREATE TABLE `lms_sheets` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`template_id` text NOT NULL,
	`course_id` text NOT NULL,
	`year_id` text NOT NULL,
	`title` text NOT NULL,
	`columns_json` text NOT NULL,
	`status` text DEFAULT 'hidden' NOT NULL,
	`opens_at` text,
	`closes_at` text,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_sheets_unique_0` ON `lms_sheets` (`template_id`,`course_id`,`year_id`);
--> statement-breakpoint
CREATE TABLE `lms_students` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`first_name` text NOT NULL,
	`last_name` text NOT NULL,
	`email` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_students_unique_0` ON `lms_students` (`teacher_id`,`email`);
--> statement-breakpoint
CREATE TABLE `lms_submission_files` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`submission_id` text NOT NULL,
	`file_id` text NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE TABLE `lms_submissions` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`assignment_id` text NOT NULL,
	`enrollment_id` text NOT NULL,
	`member_ids` text DEFAULT '[]' NOT NULL,
	`submitted_at` text NOT NULL,
	`late` integer DEFAULT 0 NOT NULL,
	`feedback` text DEFAULT '' NOT NULL,
	`grade` text DEFAULT '' NOT NULL,
	`retention_exempt` integer DEFAULT 0 NOT NULL,
	`group_id` text
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_submissions_unique_0` ON `lms_submissions` (`assignment_id`,`enrollment_id`);
--> statement-breakpoint
CREATE INDEX `lms_submissions_indexes_0` ON `lms_submissions` (`teacher_id`,`group_id`);
--> statement-breakpoint
CREATE TABLE `lms_teachers` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`slug` text NOT NULL,
	`name` text NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`code_hash` text,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_teachers_unique_0` ON `lms_teachers` (`slug`);
--> statement-breakpoint
CREATE TABLE `lms_templates` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`title` text NOT NULL,
	`columns_json` text NOT NULL,
	`original_file_id` text,
	`version` integer DEFAULT 1 NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE TABLE `lms_years` (
	`id` text PRIMARY KEY NOT NULL,
	`teacher_id` text NOT NULL,
	`label` text NOT NULL,
	`starts` text NOT NULL,
	`active` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);

--> statement-breakpoint
CREATE UNIQUE INDEX `lms_years_unique_0` ON `lms_years` (`teacher_id`,`label`);
