CREATE TABLE `login_windows` (
 `key` text PRIMARY KEY NOT NULL,
 `attempts` integer NOT NULL,
 `reset_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `sessions` (
 `digest` text PRIMARY KEY NOT NULL,
 `expires` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `settings` (
 `key` text PRIMARY KEY NOT NULL,
 `value` text NOT NULL
);
