import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'Tasnim · Owner setup',description:'One-time lesson storage connection for Tasnim Hamdeni.',robots:{index:false,follow:false}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
