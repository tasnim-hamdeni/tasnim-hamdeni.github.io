export const model = {
  "teachers": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "slug": {
        "type": "text",
        "notNull": true
      },
      "name": {
        "type": "text",
        "notNull": true
      },
      "email": {
        "type": "text",
        "notNull": true,
        "default": ""
      },
      "code_hash": {
        "type": "text",
        "notNull": false
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "slug"
      ]
    ],
    "indexes": []
  },
  "years": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "label": {
        "type": "text",
        "notNull": true
      },
      "starts": {
        "type": "text",
        "notNull": true
      },
      "active": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "teacher_id",
        "label"
      ]
    ],
    "indexes": []
  },
  "courses": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "year_id": {
        "type": "text",
        "notNull": true
      },
      "name": {
        "type": "text",
        "notNull": true
      },
      "position": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "archived": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": [
      [
        "teacher_id",
        "year_id"
      ]
    ]
  },
  "chapters": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "course_id": {
        "type": "text",
        "notNull": true
      },
      "name": {
        "type": "text",
        "notNull": true
      },
      "position": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "status": {
        "type": "text",
        "notNull": true,
        "default": "hidden"
      },
      "publish_at": {
        "type": "text",
        "notNull": false
      },
      "deleted": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": [
      [
        "teacher_id",
        "course_id"
      ]
    ]
  },
  "documents": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "chapter_id": {
        "type": "text",
        "notNull": true
      },
      "file_id": {
        "type": "text",
        "notNull": true
      },
      "title": {
        "type": "text",
        "notNull": true
      },
      "status": {
        "type": "text",
        "notNull": true,
        "default": "hidden"
      },
      "publish_at": {
        "type": "text",
        "notNull": false
      },
      "position": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "example": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "deleted": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": [
      [
        "teacher_id",
        "chapter_id"
      ],
      [
        "teacher_id",
        "file_id"
      ]
    ]
  },
  "students": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "first_name": {
        "type": "text",
        "notNull": true
      },
      "last_name": {
        "type": "text",
        "notNull": true
      },
      "email": {
        "type": "text",
        "notNull": true
      },
      "active": {
        "type": "integer",
        "notNull": true,
        "default": 1
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "teacher_id",
        "email"
      ]
    ],
    "indexes": []
  },
  "enrollments": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "student_id": {
        "type": "text",
        "notNull": true
      },
      "year_id": {
        "type": "text",
        "notNull": true
      },
      "course_id": {
        "type": "text",
        "notNull": true
      },
      "status": {
        "type": "text",
        "notNull": true,
        "default": "active"
      },
      "code_hash": {
        "type": "text",
        "notNull": true
      },
      "code_version": {
        "type": "integer",
        "notNull": true,
        "default": 1
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "student_id",
        "year_id"
      ],
      [
        "code_hash"
      ]
    ],
    "indexes": [
      [
        "teacher_id",
        "year_id",
        "course_id"
      ]
    ]
  },
  "sessions": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "role": {
        "type": "text",
        "notNull": true
      },
      "student_id": {
        "type": "text",
        "notNull": false
      },
      "enrollment_id": {
        "type": "text",
        "notNull": false
      },
      "code_version": {
        "type": "integer",
        "notNull": false
      },
      "expires": {
        "type": "integer",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": []
  },
  "settings": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "value": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "teacher_id"
      ]
    ],
    "indexes": []
  },
  "announcements": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "year_id": {
        "type": "text",
        "notNull": true
      },
      "title": {
        "type": "text",
        "notNull": true
      },
      "body": {
        "type": "text",
        "notNull": true
      },
      "course_ids": {
        "type": "text",
        "notNull": true
      },
      "status": {
        "type": "text",
        "notNull": true,
        "default": "draft"
      },
      "publish_at": {
        "type": "text",
        "notNull": false
      },
      "attachments": {
        "type": "text",
        "notNull": true,
        "default": "[]"
      },
      "created": {
        "type": "text",
        "notNull": true
      },
      "updated": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": [
      [
        "teacher_id",
        "year_id"
      ]
    ]
  },
  "announcement_reads": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "announcement_id": {
        "type": "text",
        "notNull": true
      },
      "enrollment_id": {
        "type": "text",
        "notNull": true
      },
      "read_at": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "announcement_id",
        "enrollment_id"
      ]
    ],
    "indexes": []
  },
  "attendance_sessions": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "course_id": {
        "type": "text",
        "notNull": true
      },
      "year_id": {
        "type": "text",
        "notNull": true
      },
      "date": {
        "type": "text",
        "notNull": true
      },
      "time": {
        "type": "text",
        "notNull": true,
        "default": ""
      },
      "title": {
        "type": "text",
        "notNull": true,
        "default": ""
      },
      "finalized": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "revision": {
        "type": "integer",
        "notNull": true,
        "default": 1
      },
      "created": {
        "type": "text",
        "notNull": true
      },
      "write_token": {
        "type": "text",
        "notNull": true,
        "default": ""
      }
    },
    "unique": [],
    "indexes": [
      [
        "teacher_id",
        "year_id",
        "course_id"
      ]
    ]
  },
  "attendance_records": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "session_id": {
        "type": "text",
        "notNull": true
      },
      "student_id": {
        "type": "text",
        "notNull": true
      },
      "status": {
        "type": "text",
        "notNull": true
      },
      "note": {
        "type": "text",
        "notNull": true,
        "default": ""
      },
      "updated": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "session_id",
        "student_id"
      ]
    ],
    "indexes": []
  },
  "assignments": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "course_id": {
        "type": "text",
        "notNull": true
      },
      "year_id": {
        "type": "text",
        "notNull": true
      },
      "title": {
        "type": "text",
        "notNull": true
      },
      "body": {
        "type": "text",
        "notNull": true,
        "default": ""
      },
      "deadline": {
        "type": "text",
        "notNull": false
      },
      "status": {
        "type": "text",
        "notNull": true,
        "default": "draft"
      },
      "max_file_bytes": {
        "type": "integer",
        "notNull": true,
        "default": 10485760
      },
      "max_total_bytes": {
        "type": "integer",
        "notNull": true,
        "default": 52428800
      },
      "allow_late": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "allow_replace": {
        "type": "integer",
        "notNull": true,
        "default": 1
      },
      "groups": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": [
      [
        "teacher_id",
        "year_id",
        "course_id"
      ]
    ]
  },
  "submissions": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "assignment_id": {
        "type": "text",
        "notNull": true
      },
      "enrollment_id": {
        "type": "text",
        "notNull": true
      },
      "member_ids": {
        "type": "text",
        "notNull": true,
        "default": "[]"
      },
      "submitted_at": {
        "type": "text",
        "notNull": true
      },
      "late": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "feedback": {
        "type": "text",
        "notNull": true,
        "default": ""
      },
      "grade": {
        "type": "text",
        "notNull": true,
        "default": ""
      },
      "retention_exempt": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "group_id": {
        "type": "text",
        "notNull": false
      }
    },
    "unique": [
      [
        "assignment_id",
        "enrollment_id"
      ]
    ],
    "indexes": [
      [
        "teacher_id",
        "group_id"
      ]
    ]
  },
  "submission_files": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "submission_id": {
        "type": "text",
        "notNull": true
      },
      "file_id": {
        "type": "text",
        "notNull": true
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": []
  },
  "files": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "category": {
        "type": "text",
        "notNull": true
      },
      "year_id": {
        "type": "text",
        "notNull": true
      },
      "course_id": {
        "type": "text",
        "notNull": true
      },
      "parent_id": {
        "type": "text",
        "notNull": true
      },
      "enrollment_id": {
        "type": "text",
        "notNull": false
      },
      "name": {
        "type": "text",
        "notNull": true
      },
      "mime": {
        "type": "text",
        "notNull": true
      },
      "size": {
        "type": "integer",
        "notNull": true
      },
      "provider": {
        "type": "text",
        "notNull": true
      },
      "storage_key": {
        "type": "text",
        "notNull": true,
        "default": ""
      },
      "status": {
        "type": "text",
        "notNull": true,
        "default": "pending"
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": [
      [
        "teacher_id",
        "category",
        "year_id"
      ],
      [
        "teacher_id",
        "parent_id",
        "status"
      ]
    ]
  },
  "templates": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "title": {
        "type": "text",
        "notNull": true
      },
      "columns_json": {
        "type": "text",
        "notNull": true
      },
      "original_file_id": {
        "type": "text",
        "notNull": false
      },
      "version": {
        "type": "integer",
        "notNull": true,
        "default": 1
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [],
    "indexes": []
  },
  "sheets": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "template_id": {
        "type": "text",
        "notNull": true
      },
      "course_id": {
        "type": "text",
        "notNull": true
      },
      "year_id": {
        "type": "text",
        "notNull": true
      },
      "title": {
        "type": "text",
        "notNull": true
      },
      "columns_json": {
        "type": "text",
        "notNull": true
      },
      "status": {
        "type": "text",
        "notNull": true,
        "default": "hidden"
      },
      "opens_at": {
        "type": "text",
        "notNull": false
      },
      "closes_at": {
        "type": "text",
        "notNull": false
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "template_id",
        "course_id",
        "year_id"
      ]
    ],
    "indexes": []
  },
  "project_entries": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "sheet_id": {
        "type": "text",
        "notNull": true
      },
      "enrollment_id": {
        "type": "text",
        "notNull": true
      },
      "member_ids": {
        "type": "text",
        "notNull": true,
        "default": "[]"
      },
      "values_json": {
        "type": "text",
        "notNull": true
      },
      "revision": {
        "type": "integer",
        "notNull": true,
        "default": 1
      },
      "deleted": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "updated": {
        "type": "text",
        "notNull": true
      },
      "group_id": {
        "type": "text",
        "notNull": false
      }
    },
    "unique": [
      [
        "sheet_id",
        "enrollment_id"
      ]
    ],
    "indexes": []
  },
  "project_history": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "entry_id": {
        "type": "text",
        "notNull": true
      },
      "actor_id": {
        "type": "text",
        "notNull": true
      },
      "before_json": {
        "type": "text",
        "notNull": true
      },
      "after_json": {
        "type": "text",
        "notNull": true
      },
      "revision": {
        "type": "integer",
        "notNull": true
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "entry_id",
        "revision"
      ]
    ],
    "indexes": [
      [
        "teacher_id",
        "entry_id"
      ]
    ]
  },
  "exceptions": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "parent_id": {
        "type": "text",
        "notNull": true
      },
      "enrollment_id": {
        "type": "text",
        "notNull": true
      },
      "closes_at": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "parent_id",
        "enrollment_id"
      ]
    ],
    "indexes": []
  },
  "jobs": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "kind": {
        "type": "text",
        "notNull": true
      },
      "job_key": {
        "type": "text",
        "notNull": true
      },
      "payload": {
        "type": "text",
        "notNull": true
      },
      "status": {
        "type": "text",
        "notNull": true,
        "default": "pending"
      },
      "attempts": {
        "type": "integer",
        "notNull": true,
        "default": 0
      },
      "next_run": {
        "type": "text",
        "notNull": true
      },
      "result": {
        "type": "text",
        "notNull": true,
        "default": "{}"
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "job_key"
      ]
    ],
    "indexes": []
  },
  "oauth_states": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "verifier": {
        "type": "text",
        "notNull": true
      },
      "expires": {
        "type": "integer",
        "notNull": true
      },
      "provider": {
        "type": "text",
        "notNull": true,
        "default": "onedrive"
      }
    },
    "unique": [],
    "indexes": []
  },
  "groups": {
    "columns": {
      "id": {
        "type": "text",
        "notNull": true,
        "primary": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "parent_id": {
        "type": "text",
        "notNull": true
      },
      "kind": {
        "type": "text",
        "notNull": true
      },
      "course_id": {
        "type": "text",
        "notNull": true
      },
      "year_id": {
        "type": "text",
        "notNull": true
      },
      "owner_enrollment_id": {
        "type": "text",
        "notNull": true
      },
      "member_ids": {
        "type": "text",
        "notNull": true
      },
      "invite_hash": {
        "type": "text",
        "notNull": true
      },
      "created": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "invite_hash"
      ]
    ],
    "indexes": [
      [
        "teacher_id",
        "parent_id"
      ]
    ]
  },
  "group_memberships": {
    "columns": {
      "id": {
        "type": "text",
        "primary": true,
        "notNull": true
      },
      "teacher_id": {
        "type": "text",
        "notNull": true
      },
      "parent_id": {
        "type": "text",
        "notNull": true
      },
      "group_id": {
        "type": "text",
        "notNull": true
      },
      "enrollment_id": {
        "type": "text",
        "notNull": true
      }
    },
    "unique": [
      [
        "parent_id",
        "enrollment_id"
      ]
    ],
    "indexes": [
      [
        "teacher_id",
        "group_id",
        "enrollment_id"
      ]
    ]
  }
};
