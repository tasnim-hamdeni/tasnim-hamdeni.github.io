import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const settings=sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
export const sessions=sqliteTable('sessions',{digest:text('digest').primaryKey(),expires:integer('expires').notNull()});
export const loginWindows=sqliteTable('login_windows',{key:text('key').primaryKey(),attempts:integer('attempts').notNull(),resetAt:integer('reset_at').notNull()});
