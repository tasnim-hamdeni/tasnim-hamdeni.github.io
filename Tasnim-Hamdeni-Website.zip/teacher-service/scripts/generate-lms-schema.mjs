import {model} from '../db/lms-model.mjs';
import {writeFile} from 'node:fs/promises';
let source=`import {sqliteTable,text,integer,index,uniqueIndex} from 'drizzle-orm/sqlite-core';
export const settings=sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
export const sessions=sqliteTable('sessions',{digest:text('digest').primaryKey(),expires:integer('expires').notNull()});
export const loginWindows=sqliteTable('login_windows',{key:text('key').primaryKey(),attempts:integer('attempts').notNull(),resetAt:integer('reset_at').notNull()});
// Generated from lms-model.mjs. Append migrations; never rewrite an applied migration.
`;
for(const [name,spec] of Object.entries(model)){
 const columns=Object.entries(spec.columns).map(([key,c])=>JSON.stringify(key)+':'+c.type+'('+JSON.stringify(key)+')'+(c.primary?'.primaryKey()':'')+(c.notNull?'.notNull()':'')+('default' in c?'.default('+JSON.stringify(c.default)+')':''));
 const indexes=['unique','indexes'].flatMap(kind=>(spec[kind]||[]).map((cols,i)=>`${kind==='unique'?'uniqueIndex':'index'}("lms_${name}_${kind}_${i}").on(${cols.map(c=>'t.'+c).join(',')})`));
 source+=`export const lms_${name}=sqliteTable('lms_${name}',{${columns.join(',')}}${indexes.length?',t=>['+indexes.join(',')+']':''});\n`;
}
await writeFile(new URL('../db/schema.ts',import.meta.url),source);
