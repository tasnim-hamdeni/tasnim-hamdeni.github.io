import {generateSQLiteDrizzleJson,generateSQLiteMigration} from 'drizzle-kit/api';
import * as schema from '../db/schema.ts';
import {readFile,writeFile} from 'node:fs/promises';
const legacy=Object.fromEntries(Object.entries(schema).filter(([name])=>!name.startsWith('lms_')));
const previous=await generateSQLiteDrizzleJson(legacy);
const next=await generateSQLiteDrizzleJson(schema,previous.id);
const statements=await generateSQLiteMigration(previous,next);
await writeFile(new URL('../drizzle/0001_lms_platform.sql',import.meta.url),statements.join('\n--> statement-breakpoint\n')+'\n');
await writeFile(new URL('../drizzle/meta/0001_snapshot.json',import.meta.url),JSON.stringify(next,null,2));
const journalURL=new URL('../drizzle/meta/_journal.json',import.meta.url),journal=JSON.parse(await readFile(journalURL,'utf8'));
if(!journal.entries.some(e=>e.tag==='0001_lms_platform')){journal.entries.push({idx:1,version:'6',when:1793232000000,tag:'0001_lms_platform',breakpoints:true});await writeFile(journalURL,JSON.stringify(journal,null,2));}
console.log('Generated schema-only migration:',statements.length,'statements.');
