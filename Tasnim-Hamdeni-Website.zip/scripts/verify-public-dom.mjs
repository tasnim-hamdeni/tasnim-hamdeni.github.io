// Read-only checks of the deployed application in a DOM emulator, not a visual browser.
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
const base='https://tasnim-hamdeni.github.io/';
async function get(name){const r=await fetch(new URL(name,base),{cache:'no-store',signal:AbortSignal.timeout(30000)});assert.ok(r.ok,`${name}: HTTP ${r.status}`);return r.text();}
const code=text=>text.replace(/^import .*;\r?\n/gm,'').replace(/^export /gm,'');
const config=await get('config.js'),core=await get('core.js');
const student=new JSDOM(await get('index.html'),{url:base,runScripts:'outside-only'}),w=student.window;
Object.assign(w,{TextEncoder,TextDecoder,AbortSignal,structuredClone,fetch:(...args)=>fetch(...args)});
try{
 w.eval(`${code(config)}\n${code(core)}\n${code(await get('student.js'))}`);
 for(let i=0;i<300&&w.document.getElementById('refresh').disabled;i++)await new Promise(resolve=>setTimeout(resolve,100));
 assert.equal(w.document.getElementById('refresh').disabled,false,'Student catalog request completed');
 assert.equal(w.document.getElementById('library-status').textContent,'','Public catalog loaded without error');
 assert.ok(w.document.getElementById('lessons').children.length>0,'Student view renders its content or empty state');
 console.log('Live student modules load the real public catalog and render successfully (DOM emulator).');
}finally{w.close();}
const admin=new JSDOM(await get('tasnim/'),{url:base+'tasnim/',runScripts:'outside-only'}),a=admin.window;
Object.assign(a,{TextEncoder,TextDecoder,AbortSignal,structuredClone,fetch:()=>{throw new Error('Admin verification must not call GitHub');}});
try{
 a.eval(`${code(config)}\n${code(core)}\n${code(await get('github.js'))}\n${code(await get('code-access.js'))}\n${code(await get('admin.js'))}`);
 const byId=id=>a.document.getElementById(id);
 assert.equal(byId('workspace').hidden,true);assert.equal(byId('subject-form').querySelector('fieldset').disabled,true);
 assert.equal(byId('access-code').type,'password');
 assert.ok(!a.document.body.textContent.includes('GitHub token'));
 byId('access-code').value='not-a-token';byId('connect-form').dispatchEvent(new a.Event('submit',{bubbles:true,cancelable:true}));
 assert.equal(byId('access-code').value,'');assert.match(byId('admin-status').textContent,/access code/);
 console.log('Live teacher modules initialize with editing disabled; access-code form and invalid-input clearing pass. No credential used.');
}finally{a.close();}
