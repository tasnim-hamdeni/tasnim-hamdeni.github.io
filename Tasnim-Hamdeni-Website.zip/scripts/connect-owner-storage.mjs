// One-time owner connection. Read secrets from hidden stdin, never arguments/files.
const service='https://tasnim-classroom-service.beigepear256.chatgpt.site';
const origin='https://tasnim-hamdeni.github.io';
process.stdout.write('Ready for private connection input (hidden).\n');
if(process.stdin.isTTY)process.stdin.setRawMode(true);
let input='';
await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('Private input timed out.')),60000);process.stdin.on('data',chunk=>{input+=chunk.toString();if(/[\r\n]/.test(input)){clearTimeout(timeout);resolve();}});});
if(process.stdin.isTTY)process.stdin.setRawMode(false);process.stdin.pause();
let credentials;try{credentials=JSON.parse(input.trim());}catch{throw new Error('Invalid private input.');}input='';
let session='';
async function call(path,method,body){const response=await fetch(service+path,{method,headers:{Origin:origin,'Content-Type':'application/json',...(session?{Authorization:'Bearer '+session}:{})},...(body===undefined?{}:{body:JSON.stringify(body)}),redirect:'error',signal:AbortSignal.timeout(30000)});let data=null;if(response.status!==204){try{data=await response.json();}catch{throw new Error('Storage service returned an unreadable response.');}}if(!response.ok)throw new Error('Storage request failed (HTTP '+response.status+'): '+(data?.message||'Please check owner setup.'));return data;}
try{
 const login=await call('/api/session','POST',{code:credentials.code});credentials.code='';session=login.session;
 const result=await call('/api/connection','PUT',{token:credentials.token});credentials.token='';if(!result.connected)throw new Error('Storage connection was not confirmed.');
 const ref=await call('/api/github/git/ref/heads/main','GET');const current=ref.object.sha;
 // Updating a branch to its existing SHA checks write access without changing content.
 const checked=await call('/api/github/git/refs/heads/main','PATCH',{sha:current,force:false});
 if(checked.object.sha!==current)throw new Error('Repository write verification returned an unexpected head.');
 const catalog=await call('/api/github/contents/catalog.json?ref='+current,'GET');
 if(catalog.encoding!=='base64')throw new Error('The lesson catalog could not be read.');
 console.log('Storage connected. Repository read/write access verified without changing lessons.');
}catch(error){credentials.code='';credentials.token='';console.error(error.message);process.exitCode=1;}
finally{if(session){try{await call('/api/session','DELETE');}catch{console.error('The verification session will expire automatically.');}session='';}}
