import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.resolve(fileURLToPath(new URL('../site/',import.meta.url)));
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.wasm':'application/wasm','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8'};
http.createServer(async(req,res)=>{
  try {
    const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
    if(pathname==='/__responsive'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end('<!doctype html><html lang="en"><head><title>Responsive review</title><style>body{margin:20px;font:14px system-ui;background:#e5e8f0}main{display:flex;gap:24px}iframe{width:390px;height:844px;border:1px solid #bbc3d6;flex-shrink:0}</style></head><body><h1>Student and teacher · 390px phone previews</h1><main><iframe title="Student phone preview" src="/"></iframe><iframe title="Teacher phone preview" src="/tasnim/"></iframe></main></body></html>');return;}
    const target=path.resolve(root,'.'+(pathname.endsWith('/')?pathname+'index.html':pathname));
    if (!target.startsWith(root+path.sep) && target !== root) {res.writeHead(403);res.end();return;}
    const bytes=await readFile(target);res.writeHead(200,{'Content-Type':mime[path.extname(target)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(bytes);
  } catch {res.writeHead(404);res.end('Not found');}
}).listen(4173,'127.0.0.1',()=>console.log('Preview: http://127.0.0.1:4173'));
