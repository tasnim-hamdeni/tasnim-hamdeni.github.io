import {config as websiteConfig} from '../site/config.js';
// Run locally after signing in with GitHub CLI. No token is requested or saved here.
import {spawnSync} from 'node:child_process';
import {readFile,readdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const owner='tasnim-hamdeni',dataName='tasnim-lesson-data',marker='.tasnim-prototype.json';
function gh(args,input) {
  const result=spawnSync('gh',args,{encoding:'utf8',input:input===undefined?undefined:JSON.stringify(input),maxBuffer:20*1024*1024,shell:false,windowsHide:true});
  if(result.error) throw new Error('Install GitHub CLI, then run gh auth login before running this script.');
  if(result.status!==0){const error=new Error(`GitHub CLI failed: ${result.stderr.trim()}`);error.status=/HTTP 404|Not Found/.test(result.stderr)?404:0;throw error;}
  return result.stdout.trim()?JSON.parse(result.stdout):null;
}
const api=(url,method='GET',body)=>gh(['api',url,'--method',method,...(body===undefined?[]:['--input','-'])],body);
function lookup(name) {try{return api(`repos/${owner}/${name}`);}catch(error){if(error.status===404)return null;throw error;}}
function checkMarker(name,role){
  try {
    const file=api(`repos/${owner}/${name}/contents/${marker}`);
    const value=JSON.parse(Buffer.from(file.content,'base64').toString('utf8'));
    if(value.owner===owner && value.role===role && value.application==='tasnim-lesson-library' && value.version===1)return;
  }catch{}
  throw new Error(`Refusing to change existing repository ${owner}/${name}: it has no matching prototype marker. Inspect it manually. No unrelated files will be overwritten.`);
}
function create(name,description) {console.log(`Creating public repository ${owner}/${name}…`);return api('user/repos','POST',{name,description,private:false,auto_init:true});}
async function filesIn(directory,prefix='',repositoryName) {
  const files=[];
  for(const item of await readdir(directory,{withFileTypes:true})) {
    const relative=prefix+item.name,full=path.join(directory,item.name);
    if(item.isDirectory())files.push(...await filesIn(full,relative+'/',repositoryName));
    else if(relative!==marker){
      const bytes=await readFile(full);
      if(/\.(wasm|bcmap|ttf|otf|png|jpe?g|gif|ico|pdf|pptx|zip)$/i.test(relative)){
        const blob=api(`repos/${owner}/${repositoryName}/git/blobs`,'POST',{content:bytes.toString('base64'),encoding:'base64'});
        files.push({path:relative,mode:'100644',type:'blob',sha:blob.sha});
      }else files.push({path:relative,mode:'100644',type:'blob',content:bytes.toString('utf8')});
    }
  }
  return files;
}
function commitFiles(name,branch,entries,message) {
  const base=`repos/${owner}/${name}`;
  const ref=api(`${base}/git/ref/heads/${encodeURIComponent(branch)}`),head=ref.object.sha;
  const parent=api(`${base}/git/commits/${head}`);
  const tree=api(`${base}/git/trees`,'POST',{base_tree:parent.tree.sha,tree:entries});
  const commit=api(`${base}/git/commits`,'POST',{message,tree:tree.sha,parents:[head]});
  api(`${base}/git/refs/heads/${encodeURIComponent(branch)}`,'PATCH',{sha:commit.sha,force:false});
  return commit.sha;
}
async function main() {
  const user=api('user');
  if(user.login.toLowerCase()!==owner.toLowerCase())throw new Error(`Sign in as ${owner}; the current CLI account is ${user.login}.`);
  // Inspect all destinations before the first write. Preserve an unrelated user site.
  const userSite=lookup(owner.toLowerCase()+'.github.io');
  let siteName=owner.toLowerCase()+'.github.io';
  if(userSite)checkMarker(siteName,'website');
  let site=siteName===owner.toLowerCase()+'.github.io'?userSite:lookup(siteName);
  let data=lookup(dataName);
  if(site)checkMarker(siteName,'website');
  if(data)checkMarker(dataName,'data');
  if(site?.private||data?.private)throw new Error('Existing prototype repositories must be public. Inspect repository visibility manually.');
  const siteIsNew=!site,dataIsNew=!data;
  if(dataIsNew)data=create(dataName,'Public lesson catalog and documents for Tasnim Hamdeni');
  if(siteIsNew)site=create(siteName,'Tasnim Hamdeni — public lesson library');
  const makeMarker=role=>({path:marker,mode:'100644',type:'blob',content:JSON.stringify({application:'tasnim-lesson-library',version:1,owner,role},null,2)});
  if(dataIsNew)commitFiles(dataName,data.default_branch,[...await filesIn(path.join(root,'lesson-data'),'',dataName),makeMarker('data')],'Initialize public example catalog');
  const branch=data.default_branch;
  const siteURL=`https://${owner.toLowerCase()}.github.io/${siteName===owner.toLowerCase()+'.github.io'?'':siteName+'/'}`;
  const entries=(await filesIn(path.join(root,'site'),'',siteName)).filter(entry=>entry.path!=='README.md');
  entries.find(e=>e.path==='config.js').content=`export const config = Object.freeze(${JSON.stringify({owner,repository:dataName,branch,catalogPath:'catalog.json',adminService:websiteConfig.adminService,maxUploadBytes:50*1024*1024},null,2)});\n`;
  entries.push(makeMarker('website'),{path:'README.md',mode:'100644',type:'blob',content:await readFile(path.join(root,'site','README.md'),'utf8')});
  const commit=commitFiles(siteName,site.default_branch,entries,'Publish Tasnim Hamdeni lesson library');
  let pages;
  try{pages=api(`repos/${owner}/${siteName}/pages`);}catch(error){if(error.status!==404)throw error;}
  if(pages) {
    if(pages.cname || pages.build_type!=='legacy' || pages.source?.branch!==site.default_branch || pages.source?.path!=='/')throw new Error('Pages already has a different domain or publishing source. Inspect Settings → Pages manually; this script will preserve that configuration.');
  } else pages=api(`repos/${owner}/${siteName}/pages`,'POST',{build_type:'legacy',source:{branch:site.default_branch,path:'/'}});
  // Request a build explicitly so an API commit is not mistaken for a verified deployment.
  try{api(`repos/${owner}/${siteName}/pages/builds`,'POST',{});}catch(error){console.log('Pages is configured. If a build has not started, open Settings → Pages.');}
  const record={owner,websiteRepository:`${owner}/${siteName}`,dataRepository:`${owner}/${dataName}`,configuredURL:pages.html_url||siteURL,commit,status:'configured-awaiting-verification',checkedAt:new Date().toISOString()};
  await writeFile(path.join(root,'deployment-status.json'),JSON.stringify(record,null,2)+'\n');
  console.log(`Pages configured: ${record.configuredURL}\nAdmin: ${record.configuredURL}tasnim/\nBuilds can take up to 10 minutes. Waiting for this version to become public…`);
  for(let attempt=0;attempt<60;attempt++) {
    try {
      const build=api(`repos/${owner}/${siteName}/pages/builds/latest`);
      if(build.status==='errored')throw new Error('GitHub Pages build failed. Open repository Settings → Pages for details.');
      if(build.status==='built' && build.commit===commit) {
        const response=await fetch(record.configuredURL,{cache:'no-store'});
        if(response.ok && (await response.text()).includes('Tasnim Hamdeni')) {
          record.status='published';record.publishedURL=record.configuredURL;record.checkedAt=new Date().toISOString();
          await writeFile(path.join(root,'deployment-status.json'),JSON.stringify(record,null,2)+'\n');
          console.log(`Published and verified: ${record.publishedURL}`);return;
        }
      }
    }catch(error){if(/build failed/.test(error.message))throw error;}
    await new Promise(resolve=>setTimeout(resolve,10000));
  }
  throw new Error(`Pages is configured, but publication was not verified within 10 minutes. Check https://github.com/${owner}/${siteName}/settings/pages and visit ${siteURL}.`);
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
