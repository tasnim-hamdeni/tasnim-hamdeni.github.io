// Owner-only verification / non-destructive legacy import. Never logs credentials.
import {config} from '../site/config.js';
const origin='https://tasnim-hamdeni.github.io',base=config.adminService+'/api/lms';
process.stdout.write('Ready for teacher code on hidden stdin.\n');if(process.stdin.isTTY)process.stdin.setRawMode(true);
let input='';await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('Input timed out.')),120000);process.stdin.on('data',chunk=>{input+=chunk.toString();if(/[\r\n]/.test(input)){clearTimeout(timeout);resolve();}});});if(process.stdin.isTTY)process.stdin.setRawMode(false);process.stdin.pause();
let session='';
async function call(path,method='GET',data){const response=await fetch(base+path,{method,headers:{Origin:origin,'Content-Type':'application/json',...(session?{Authorization:'Bearer '+session}:{})},body:data===undefined?undefined:JSON.stringify(data),redirect:'error',signal:AbortSignal.timeout(60000)});const value=await response.json();if(!response.ok)throw new Error('Classroom request failed: HTTP '+response.status+' '+(value.error||''));return value;}
try{const result=await call('/session','POST',{role:'teacher',code:input.trim()});input='';session=result.session;
 if(process.argv.includes('--import-legacy')){const imported=await call('/import-legacy','POST',{});console.log('Preserved/imported catalog: '+imported.courses+' courses, '+imported.chapters+' chapters, '+imported.documents+' documents.');}
 const state=await call('/state');console.log('Teacher access verified. '+state.courses.length+' courses, '+state.chapters.length+' chapters, '+state.documents.length+' documents.');
 const storage=await call('/storage');console.log('Google Drive: '+(storage.connected?'connected':'owner setup required')+'.');
 if(process.argv.includes('--storage-check')){const check=await call('/storage/test','POST',{});if(!check.verified||!check.cleanupConfirmed)throw new Error('Storage round-trip did not complete.');console.log('Live Drive upload, byte-for-byte download, and test-file cleanup: verified.');}
 const noSession=await fetch(base+'/state',{headers:{Origin:origin},redirect:'error'});if(noSession.status!==401)throw new Error('Unauthenticated access was not rejected.');console.log('Private data access guard: verified.');
}catch(error){input='';console.error(error.message);process.exitCode=1;}finally{if(session){try{await call('/session','DELETE');console.log('Verification session revoked.');}catch{console.error('Verification session will expire automatically.');}session='';}}
