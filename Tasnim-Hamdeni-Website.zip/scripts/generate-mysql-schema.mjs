// Preparation for a future MySQL 8 migration; this does not connect to a server.
import {model} from '../teacher-service/db/lms-model.mjs';
import {writeFile} from 'node:fs/promises';
const long=new Set(['body','columns_json','values_json','before_json','after_json','value','payload','result','storage_key','member_ids','course_ids','attachments']);
const quote=value=>"'"+String(value).replaceAll("'","''")+"'";
let sql='-- Tasnim Classroom: MySQL 8 preparation only. Not deployed.\n-- Export/import rows privately; provision fresh authentication credentials.\n-- No production records, sessions, or OAuth secrets are included here.\n\n';
for(const [name,table] of Object.entries(model)){
 const lines=Object.entries(table.columns).map(([name,c])=>{
  const type=c.type==='integer'?'BIGINT':long.has(name)?'MEDIUMTEXT':name==='email'?'VARCHAR(320)':name.endsWith('_hash')?'CHAR(64)':name==='id'||name==='teacher_id'||name.endsWith('_id')?'VARCHAR(100)':'VARCHAR(255)';
  const def='default' in c?' DEFAULT '+(c.type==='integer'?c.default:long.has(name)?'('+quote(c.default)+')':quote(c.default)):'';
  return '  `'+name+'` '+type+(c.notNull?' NOT NULL':' NULL')+def+(c.primary?' PRIMARY KEY':'');
 });
 for(const [kind,groups] of [['UNIQUE KEY',table.unique||[]],['KEY',table.indexes||[]]])groups.forEach((columns,i)=>lines.push('  '+kind+' `lms_'+name+'_'+(kind==='KEY'?'index':'unique')+'_'+i+'` ('+columns.map(c=>'`'+c+'`').join(',')+')'));
 sql+='CREATE TABLE `lms_'+name+'` (\n'+lines.join(',\n')+'\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;\n\n';
}
await writeFile(new URL('../docs/schema-mysql8.sql',import.meta.url),sql);
console.log('Generated MySQL 8 preparation schema; no database was contacted.');
