"""Create a portable source ZIP with an explicit allowlist; exclude generated data."""
from pathlib import Path
import hashlib
import json
import re
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
destination = root / "Tasnim-Hamdeni-Website.zip"
sources = [root / name for name in [".gitignore", "README.md", "TEST-REPORT.md", "deployment-status.json", "package.json", "package-lock.json"]]
for directory in ["site", "lesson-data", "scripts", "tests"]:
    sources.extend(p for p in (root / directory).rglob("*") if p.is_file() and "__pycache__" not in p.parts)

for source in sources:
    text = source.read_text(encoding="utf-8")
    if re.search(r"(?:github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)", text):
        raise SystemExit(f"Possible credential detected; refusing to package {source.name}.")

catalog = json.loads((root / "lesson-data/catalog.json").read_text())
assert catalog["subjects"] == [] and catalog["chapters"] == [] and catalog["lessons"] == [], "Delivered catalog must be empty."
with ZipFile(destination, "w", ZIP_DEFLATED) as archive:
    for source in sorted(sources):
        archive.write(source, source.relative_to(root).as_posix())

with ZipFile(destination) as archive:
    assert archive.testzip() is None
    assert not any(name.startswith(("artifacts/", ".git/", "node_modules/")) for name in archive.namelist())
    print(f"Verified {len(archive.namelist())} source files; no test documents or credentials detected.")
digest = hashlib.sha256(destination.read_bytes()).hexdigest()
(root / "Tasnim-Hamdeni-Website.zip.sha256").write_text(f"{digest}  {destination.name}\n")
print(f"ZIP: {destination}\nSHA-256: {digest}")
