// Read-only verification: no GitHub credentials, mutations, or document uploads.
import {readFile} from 'node:fs/promises';
import {config} from '../site/config.js';
import {validateCatalog} from '../site/core.js';
const base='https://tasnim-hamdeni.github.io/';
const files=['index.html','admin.html','tasnim/index.html','styles.css','config.js','core.js','github.js','student.js','admin.js','assets/mark.svg'];
const normalize=text=>text.replace(/\r\n/g,'\n').trimEnd();
for(const name of files){
  const response=await fetch(new URL(name,base),{cache:'no-store',signal:AbortSignal.timeout(30000)});
  if(!response.ok)throw new Error(`${name}: HTTP ${response.status}`);
  const actual=await response.text(),expected=await readFile(new URL('../site/'+name,import.meta.url),'utf8');
  if(normalize(actual)!==normalize(expected))throw new Error(`${name}: public content differs from the delivered source`);
  console.log(`${name}: HTTP ${response.status}, matches source`);
}
const catalogURL=`https://raw.githubusercontent.com/${config.owner}/${config.repository}/${config.branch}/${config.catalogPath}`;
const response=await fetch(catalogURL,{cache:'no-store',credentials:'omit',signal:AbortSignal.timeout(30000)});
if(!response.ok)throw new Error(`Catalog: HTTP ${response.status}`);
const catalog=validateCatalog(await response.json());
console.log(`Public catalog: valid JSON, ${catalog.subjects.length} subjects, ${catalog.chapters.length} chapters, ${catalog.lessons.length} documents`);
