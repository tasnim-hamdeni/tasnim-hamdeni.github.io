// Local QA only. Uses an in-memory SQLite database and disposable fixture accounts.
import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {Readable} from 'node:stream';
import {database} from '../teacher-service/tests/d1-sqlite.mjs';
import {handleLms} from '../teacher-service/lib/lms-api.mjs';
const DB=database(),env={DB,ACCESS_CODE:'local-teacher',TOKEN_KEY:'ab'.repeat(32),ALLOW_LOCAL_PREVIEW:'1'},root=resolve('site');
const request=async(path,data,token)=>{const r=await handleLms(new Request('http://localhost:4173/api/lms'+path,{method:data?'POST':'GET',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:data?JSON.stringify(data):undefined}),env);const result=await r.json();if(!r.ok)throw new Error(result.error);return result;};
const login=await request('/session',{role:'teacher',code:env.ACCESS_CODE}),token=login.session,state=await request('/state',null,token),yearId=state.year.id;
const action=(action,data)=>request('/command',{action,...data},token);
const course=await action('courses.save',{yearId,name:'Local QA course'}),chapter=await action('chapters.save',{courseId:course.id,name:'Local QA chapter'});await action('chapters.save',{id:chapter.id,courseId:course.id,name:'Local QA chapter',status:'published'});
const student=await action('students.import',{yearId,courseId:course.id,rows:[{firstName:'QA',lastName:'Student',email:'qa@example.test'}]});
const template=await action('templates.save',{title:'QA projects',columns:[{id:'topic',label:'Topic'},{id:'private_grade',label:'Private grade',protected:true,teacherOnly:true}]});await action('sheets.assign',{templateId:template.id,yearId,courseIds:[course.id]});
for(const sheet of DB.sqlite.prepare('SELECT id FROM lms_sheets').all())await action('sheets.save',{id:sheet.id,status:'published'});
await action('assignments.save',{courseId:course.id,title:'QA homework',body:'Local-only test assignment',status:'published'});
await action('announcements.save',{yearId,courseIds:[course.id],title:'QA announcement',body:'Local-only test announcement',status:'published'});
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.json':'application/json','.wasm':'application/wasm','.bcmap':'application/octet-stream','.ttf':'font/ttf'};
http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost:4173');if(url.pathname.startsWith('/api/lms/')){const init={method:req.method,headers:req.headers};if(!['GET','HEAD'].includes(req.method)){init.body=Readable.toWeb(req);init.duplex='half';}const response=await handleLms(new Request(url,init),env);res.writeHead(response.status,Object.fromEntries(response.headers));if(response.body)Readable.fromWeb(response.body).pipe(res);else res.end();return;}
 let path=resolve(root,'.'+decodeURIComponent(url.pathname));if(path!==root&&!path.startsWith(root+sep)){res.writeHead(403);res.end();return;}if((await stat(path)).isDirectory())path=resolve(path,'index.html');const data=await readFile(path);res.writeHead(200,{'Content-Type':types[extname(path)]||'application/octet-stream','Cache-Control':'no-store'});res.end(data);
 }catch{res.writeHead(404);res.end('Not found');}}).listen(4173,'127.0.0.1',()=>{console.log('Local classroom preview http://localhost:4173');console.log('Disposable teacher code: local-teacher');console.log('Disposable student code: '+student.issuedCodes[0].code);});
