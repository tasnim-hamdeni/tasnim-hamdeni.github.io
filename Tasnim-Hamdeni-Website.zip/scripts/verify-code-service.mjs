// Run interactively with Node.js 22+. Input is hidden; no code/session is logged.
const origin='https://tasnim-hamdeni.github.io';
const service='https://tasnim-classroom-service.beigepear256.chatgpt.site';
process.stdout.write('Ready for access code (input hidden).\n');
if(process.stdin.isTTY)process.stdin.setRawMode(true);
let input='';
await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('Input timed out.')),60000);process.stdin.on('data',chunk=>{input+=chunk.toString();if(/[\r\n]/.test(input)){clearTimeout(timeout);resolve();}});});
if(process.stdin.isTTY)process.stdin.setRawMode(false);process.stdin.pause();
let code=input.trim();input='';
const response=await fetch(service+'/api/session',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({code}),signal:AbortSignal.timeout(30000)});code='';
const data=await response.json();if(!response.ok)throw new Error('Access-code sign-in failed: HTTP '+response.status);
if(!/^[a-f0-9]{64}$/.test(data.session))throw new Error('No valid session was issued.');
const check=await fetch(service+'/api/github',{headers:{Origin:origin,Authorization:'Bearer '+data.session},signal:AbortSignal.timeout(30000)});
console.log('Live access-code sign-in: passed.');
console.log(data.setupRequired?'Owner storage connection: required.':'Owner storage connection: configured.');
console.log('Authenticated library request: HTTP '+check.status+'.');
const logout=await fetch(service+'/api/session',{method:'DELETE',headers:{Origin:origin,Authorization:'Bearer '+data.session},signal:AbortSignal.timeout(30000)});data.session='';if(logout.status!==204)throw new Error('Session revocation failed.');console.log('Live sign-out: passed.');
